from typing import List

from pydantic import BaseModel


class ChartHistoricalData(BaseModel):
    updated_at: str
    price: float


class ErrorSchema(BaseModel):
    data: str


class NotFound(ErrorSchema):
    pass


class InternalServerError(ErrorSchema):
    pass


class UnprocessableEntity(ErrorSchema):
    pass


class Unauthorized(ErrorSchema):
    human: str


class BadRequest(ErrorSchema):
    pass


class MarketIndexSchema(BaseModel):
    market_date_to: str
    market_date_from: str
    etf_name: str
    etf_symbol: str
    price: float
    change: float
    change_percent: float
    volume: float
    chart_data: List[ChartHistoricalData]


class MarketIndexResponseSchema(BaseModel):
    data: MarketIndexSchema


class Attributes(BaseModel):
    etf_name: str
    etf_symbol: str
    price: float
    change: float
    change_percent: float
    volume: int
    createdAt: str
    updatedAt: str
    publishedAt: str
    market_date_to: str
    market_date_from: str
    chart_data: List[ChartHistoricalData]


class DataItem(BaseModel):
    id: int
    attributes: Attributes


class Pagination(BaseModel):
    page: int
    pageSize: int
    pageCount: int
    total: int


class Meta(BaseModel):
    pagination: Pagination


class EtfMarketTicker(BaseModel):
    data: List[DataItem]
    meta: Meta
