from pydantic import BaseModel


class IntrinioTickerDetail(BaseModel):
    id: int
    security_id: str
    company_id: str
    stock_exchange_id: str
    name: str
    code: str
    currency: str
    ticker: str
    composite_ticker: str
    figi: str
    composite_figi: str
    share_class_figi: str
    primary_listing: bool
