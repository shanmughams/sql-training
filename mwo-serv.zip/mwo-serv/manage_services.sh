#!/bin/bash

SERVICES=("rqscheduler" "rqworker" "rqsignalworker" "fastapi" "rqdashboard")

case $1 in
    start)
        for SERVICE in "${SERVICES[@]}"; do
            echo "Starting $SERVICE"
            sudo systemctl start "$SERVICE.service"
        done
        ;;
    stop)
        for SERVICE in "${SERVICES[@]}"; do
            echo "Stopping $SERVICE"
            sudo systemctl stop "$SERVICE.service"
        done
        ;;
    enable)
        for SERVICE in "${SERVICES[@]}"; do
            echo "Enabling $SERVICE"
            sudo systemctl enable "$SERVICE.service"
        done
        ;;
    restart)
        for SERVICE in "${SERVICES[@]}"; do
            echo "restarting $SERVICE"
            sudo systemctl restart "$SERVICE.service"
        done
        ;;
    status)
        for SERVICE in "${SERVICES[@]}"; do
            echo "Status of $SERVICE"
            sudo systemctl status "$SERVICE.service"
        done
        ;;
    *)
        echo "Usage: $0 {start|stop|enable|restart|status}"
        ;;
esac