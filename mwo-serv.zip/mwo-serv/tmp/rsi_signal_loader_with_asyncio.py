import os
from datetime import datetime, timedelta
from typing import Dict, List

import httpx
from holiday import is_holiday, is_weekend
from starlette import status

from core.config import settings
from core.logger import logger
from tmp.etf_signals import (
    create_signal,
    find_signal_by_transaction_id,
    find_signals_by_symbol_buy_date,
    get_rsi_signals,
    get_tradesmith_access_token,
    prepare_signal_body,
    update_signal,
)
from utils.constants import MARKET_CAP_LIMIT
from utils.util import get_strapi_headers


def generate_workday_dates_for_days(days_count: int):
    today = datetime.now()
    start_date = today - timedelta(days_count)
    date_list = []

    for n in range((today - start_date).days + 1):
        date = start_date + timedelta(n)
        if not is_weekend(date) and not is_holiday(date):
            date_list.append(date.strftime("%Y-%m-%d"))

    return date_list


async def get_last_update_date_from_strapi():
    last_update_date = None
    async with httpx.AsyncClient() as client:
        try:
            api_params = {"sort": "update_date:desc", "pagination[limit]": "1"}
            strapi_api_headers = get_strapi_headers()
            response = await client.get(
                url=settings.strapi_signals_endpoint,
                headers=strapi_api_headers,
                params=api_params,
            )
            if response.status_code == status.HTTP_200_OK:
                data = response.json().get("data", [{}])
                if data:
                    attributes = data[0].get("attributes", "")
                    update_date = data[0].get("attributes", "").get("update_date", "")
                    if data and attributes and update_date:
                        last_update_date = update_date
                    else:
                        logger.error(
                            f"last_update_date: {last_update_date} status_code: {response.status_code}"
                        )
                else:
                    logger.warning(f"No Signals Records Found in strapi! data :{data}")
        except Exception as e:
            logger.error(f"Error during in getting last_update_date: {e}")
        return last_update_date


async def save_signals_in_strapi(signals: List[Dict], report_file) -> None:
    """
    Save signals into Strapi Collection
    @param signals: List
    @return: None
    """
    for signal in signals:
        market_cap = signal.get("MarketCap", None)
        if market_cap and market_cap >= MARKET_CAP_LIMIT:
            txn_id = signal.get("TransactionId", None)
            if txn_id:
                signal_by_txn = await find_signal_by_transaction_id(txn_id)
                if signal_by_txn:
                    attributes = signal_by_txn["attributes"]
                    symbol_id = signal_by_txn["id"]
                    attributes["update_date"] = signal.get("UpdateDate")
                    sell_date = signal.get("SellDate", None)
                    if sell_date:
                        attributes["update_date"] = signal.get("UpdateDate")
                        attributes["entry_rsi_sell_date"] = signal.get(
                            "EntryRsiSellDate"
                        )
                        attributes["sell_rsi"] = signal.get("SellRsi")
                        attributes["old_sell_date"] = signal.get("SellDate")
                        attributes["old_sell_price"] = signal.get("SellPrice")
                    report_file.write(
                        f"update existing symbol - {symbol_id}, txn id - {txn_id}\n"
                    )
                    logger.info(
                        f"update existing symbol - {symbol_id}, txn id - {txn_id}\n"
                    )
                    await update_signal(symbol_id, attributes)

                else:
                    signal_by_id_buy_date_threshold = (
                        await find_signals_by_symbol_buy_date(signal)
                    )
                    if signal_by_id_buy_date_threshold:
                        attributes = signal_by_id_buy_date_threshold["attributes"]
                        symbol_id = signal_by_id_buy_date_threshold["id"]
                        if attributes["count"] is None:
                            attributes["count"] = 1
                        else:
                            attributes["count"] += 1
                            logger.info(
                                f"update existing symbol - {symbol_id}, txn id - {txn_id}\n"
                            )
                        report_file.write(
                            f"update existing symbol - {symbol_id}, txn id - {txn_id}\n"
                        )
                        await update_signal(symbol_id, attributes)
                    else:
                        logger.info(f"Creating new - {signal['SymbolId']}")
                        signal = prepare_signal_body(signal)
                        report_file.write(
                            f"Created [{signal["symbol"]}] signal with txn id - [{signal["transaction_id"]}]\n"
                        )
                        await create_signal(signal)
            else:
                logger.error(f"Getting txn_id: {txn_id} ")


async def get_rsi_signals_all_with_date(last_update_date, access_token, report_file):
    try:
        logger.info(f"{last_update_date}")
        last_update_date_str = last_update_date + "T00:00:00"
        rsi_signals = await get_rsi_signals(access_token, last_update_date_str)
        if rsi_signals and len(rsi_signals) > 0:
            rec = (
                f"Total RSI Received - [{len(rsi_signals)}], "
                f"for the date - [{last_update_date_str}] \n"
            )
            logger.info(rec)
            report_file.write(rec)
            await save_signals_in_strapi(rsi_signals, report_file)
        else:
            logger.info(
                f"No RSI signals available for - {last_update_date_str} in Tradesmith API"
            )
    except Exception as e:
        logger.error(f"Error during Getting RSI signals: {e}")


async def get_rsi_signals_for_days(days: int):
    dates = generate_workday_dates_for_days(days)  # 200 days
    date_list_len = len(dates)
    i = 0
    current_datetime = datetime.now().strftime("%Y-%m-%d:%H-%M-%S")
    report_file_name = os.path.join("reports", f"signals_report_{current_datetime}.txt")
    os.makedirs(os.path.dirname(report_file_name), exist_ok=True)
    with open(report_file_name, "a") as report_file:
        while i < date_list_len:
            last_fetch_date = dates[i]
            cron_run_date = dates[i + 1]
            logger.info(
                f"last update date : {last_fetch_date}, current cron run date : {cron_run_date}"
            )
            report_file.write(
                f"{i+1} - last update date : {last_fetch_date}, run date : {cron_run_date}\n"
            )
            try:
                auth_token = await get_tradesmith_access_token()
                await get_rsi_signals_all_with_date(
                    last_fetch_date, auth_token, report_file
                )
            except Exception as ex:
                logger.error(f"Error during Getting RSI signals: {ex}")
            i += 1
    logger.info(f"Signal Cron Ended on {datetime.now()}")
    report_file.write(f"Signal Cron Ended on {datetime.now()}")
    return True
