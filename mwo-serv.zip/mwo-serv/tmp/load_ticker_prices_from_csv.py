import glob
import os
from datetime import datetime, timedelta

import pandas as pd
from sqlalchemy import create_engine

# import psycopg2


directory_path = "../resources"
log_file_path = "ticker-price-load.log"

# Database connection settings
db_user = "abhishek"
db_password = "novell"
db_host = "localhost"
db_port = "5432"
db_name = "api"
table_name = "intrinio_ticker_prices"

engine = create_engine(f"postgresql://abhishek:novell@localhost:5432/api")


# Function to get the latest date for each ticker from the database
def get_latest_dates():
    query = "SELECT ticker, MAX(date) as max_date FROM public.intrinio_ticker_prices GROUP BY ticker"
    latest_dates = pd.read_sql(query, engine)
    print(latest_dates)
    return dict(zip(latest_dates["ticker"], latest_dates["max_date"]))


# Get the date 15 months ago
fifteen_months_ago = datetime.now() - timedelta(days=15 * 30)

# Get the latest dates from the database
latest_dates = get_latest_dates()

# Get the list of all CSV files in the directory
csv_files = glob.glob(os.path.join(directory_path, "*.csv"))

with open(log_file_path, "w") as log_file:
    # Iterate through all CSV files and process them
    for file_path in csv_files:
        print(f"Processing file: {file_path}")
        log_file.write(f"Processing file: {file_path}\n")

        # Read the CSV file
        df = pd.read_csv(file_path)
        df.columns = df.columns.str.lower()
        # Convert DATE column to datetime
        df["date"] = pd.to_datetime(df["date"])

        filtered_dfs = []
        ticker_record_counts = {}
        for ticker, group in df.groupby("ticker"):
            if ticker in latest_dates:
                min_date = latest_dates[ticker] + timedelta(days=1)
            else:
                min_date = fifteen_months_ago

            filtered_group = group[group["date"] >= min_date]
            filtered_dfs.append(filtered_group)
            ticker_record_counts[ticker] = len(filtered_group)

        if filtered_dfs:
            filtered_df = pd.concat(filtered_dfs, ignore_index=True)

            # Store the filtered data in the PostgreSQL table
            filtered_df.to_sql(table_name, engine, if_exists="append", index=False)

            # Print and log the number of records inserted from this file
            record_count = len(filtered_df)
            print(
                f"Records inserted from {os.path.basename(file_path)}: {record_count}"
            )
            log_file.write(
                f"Records inserted from {os.path.basename(file_path)}: {record_count}\n"
            )

            # Log the number of records for each ticker symbol
            for ticker, count in ticker_record_counts.items():
                print(f"{ticker}: {count} records")
                log_file.write(f"{ticker}: {count} records\n")
        else:
            print(f"No new records to insert from {os.path.basename(file_path)}.")
            log_file.write(
                f"No new records to insert from {os.path.basename(file_path)}.\n"
            )
