from datetime import datetime, timedelta
from typing import Dict, List


def filter_buys_no_sell(
    result_buys: List[Dict], result_sells: List[Dict]
) -> List[Dict]:
    result_buys_no_sell = []

    for buy in result_buys:
        exists = any(
            table["symbol"] == buy["symbol"]
            and (
                not (
                    table["stopLoss"]
                    and datetime.strptime(table["sellDate"], "%Y-%m-%d")
                    + timedelta(days=30)
                    <= datetime.strptime(buy["buyDate"], "%Y-%m-%d")
                )
                or not (
                    not table["stopLoss"]
                    and datetime.strptime(table["sellDate"], "%Y-%m-%d")
                    <= datetime.strptime(buy["buyDate"], "%Y-%m-%d")
                )
            )
            and not (
                datetime.now() - timedelta(days=18)
                <= datetime.strptime(table["sellDate"], "%Y-%m-%d")
            )
            for table in result_sells
        )
        if not exists:
            result_buys_no_sell.append(buy)

    return result_buys_no_sell


# Example usage
result_buys = [
    {"symbol": "AAPL", "buyDate": "2023-06-01"},
    {"symbol": "GOOGL", "buyDate": "2023-07-01"},
]

result_sells = [
    {"symbol": "AAPL", "sellDate": "2023-05-01", "stopLoss": True},
    {"symbol": "GOOGL", "sellDate": "2023-06-20", "stopLoss": False},
]

filtered_buys = filter_buys_no_sell(result_buys, result_sells)
print(filtered_buys)
