import os

ROOT_DIR = os.path.dirname(os.path.abspath(__file__))
LOGS_DIR = os.path.join(os.path.dirname(ROOT_DIR), "logs1")

# Create the logs directory if it doesn't exist
os.makedirs(LOGS_DIR, exist_ok=True)
