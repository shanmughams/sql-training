import holidays


# Function to check if a date is a weekend
def is_weekend(date):
    return date.weekday() >= 5  # 5 = Saturday, 6 = Sunday


# Function to check if a date is a NYSE holiday
def is_holiday(date):
    us_holidays = holidays.US()
    return date in us_holidays
