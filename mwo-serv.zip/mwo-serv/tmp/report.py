from typing import Dict


class RSISignalsCronSummaryReport:
    def __init__(self):
        # Cron Information
        self.cron_start_time_formatted: str = ""
        self.cron_end_time_formatted: str = ""

        # RSI Signals Downloads
        self.total_rsi_signals_from_api: int = 0
        self.total_rsi_signals_over_500m_cap: int = 0
        self.total_new_rsi_signals_from_api: int = 0
        self._rsi_signals_with_matching_txn_id: Dict[str, int] = {}  # symbol, count
        self._rsi_signals_with_matching_symbol_buy_date: Dict[str, int] = (
            {}
        )  # symbol, count

        # RSI Signal Processing
        self.total_rsi_signals_on_buy_threshold: int = 0
        self.total_rsi_signals_with_min_score_on_4: int = 0

        self.total_rsi_signals_with_new_symbol_ids: int = 0
        self.total_rsi_signals_on_existing_symbol_ids: int = 0

        # Ticker Details
        self.total_existing_ticker_details: int = 0
        self.new_ticker_details: int = 0

        # Signals Returns
        self._rsi_signals_sell_goal_handled: Dict[str, int] = {}  # symbol, count
        self._rsi_signals_stop_loss_handled: Dict[str, int] = {}  # symbol, count

    # Method to add key to rsi_signals_with_matching_symbol_buy_date
    def add_rsi_signals_with_matching_symbol_buy_date(self, symbol: str) -> None:
        if not isinstance(symbol, str):
            raise ValueError("Symbol must be a string")
        if symbol in self._rsi_signals_with_matching_symbol_buy_date:
            self._rsi_signals_with_matching_symbol_buy_date[symbol] += 1
        else:
            self._rsi_signals_with_matching_symbol_buy_date[symbol] = 1

    # Method to get the count of all values in rsi_signals_with_matching_symbol_buy_date
    def get_total_rsi_signals_with_matching_symbol_buy_date(self) -> int:
        return sum(self._rsi_signals_with_matching_symbol_buy_date.values())


# Example usage
report = RSISignalsCronSummaryReport()
report.add_rsi_signals_with_matching_symbol_buy_date("AAPL")
report.add_rsi_signals_with_matching_symbol_buy_date("AAPL")
report.add_rsi_signals_with_matching_symbol_buy_date("GOOG")
report.add_rsi_signals_with_matching_symbol_buy_date("MSFT")
report.add_rsi_signals_with_matching_symbol_buy_date("GOOG")

print(
    "RSI Signals with Matching Symbol Buy Date:",
    report._rsi_signals_with_matching_symbol_buy_date,
)
print(
    "Total RSI Signals with Matching Symbol Buy Date:",
    report.get_total_rsi_signals_with_matching_symbol_buy_date(),
)
