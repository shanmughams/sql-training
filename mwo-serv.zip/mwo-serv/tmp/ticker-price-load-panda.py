import glob
import os
from datetime import datetime, timedelta

import pandas as pd
from sqlalchemy import create_engine

# Directory containing the CSV files
directory_path = "../resources"
log_file_path = "ticker-price-load.log"

# Get the list of all CSV files in the directory
csv_files = glob.glob(os.path.join(directory_path, "*.csv"))

# Get the date 15 months ago
fifteen_months_ago = datetime.now() - timedelta(days=15 * 30)

# Create an empty DataFrame to hold all the filtered data
all_filtered_data = pd.DataFrame()

with open(log_file_path, "w") as log_file:
    # Iterate through all CSV files and process them
    for file_path in csv_files:
        print(f"Processing file: {file_path}")
        log_file.write(f"Processing file: {file_path}\n")

        # Read the CSV file
        df = pd.read_csv(file_path)

        # Convert DATE column to datetime
        df["DATE"] = pd.to_datetime(df["DATE"])

        # Filter data for the last 15 months or all available data if less than 15 months
        filtered_dfs = []
        for ticker, group in df.groupby("TICKER"):
            max_date = group["DATE"].max()
            min_date = max_date - timedelta(days=15 * 30)
            if min_date < group["DATE"].min():
                min_date = group["DATE"].min()
            filtered_dfs.append(group[group["DATE"] >= min_date])

        filtered_df = pd.concat(filtered_dfs, ignore_index=True)

        # Append the filtered data to the main DataFrame
        all_filtered_data = pd.concat(
            [all_filtered_data, filtered_df], ignore_index=True
        )

        # Print and log the number of records inserted from this file
        record_count = len(filtered_df)
        print(f"Records inserted from {os.path.basename(file_path)}: {record_count}")
        log_file.write(f"Records inserted: {record_count}\n")

        # Count the number of records for each ticker symbol and log them
        ticker_counts = filtered_df["TICKER"].value_counts()
        for ticker, count in ticker_counts.items():
            print(f"{ticker}: {count} records")
            log_file.write(f"{ticker}: {count} records\n")

    # Database connection settings
    db_user = "your_db_user"
    db_password = "your_db_password"
    db_host = "your_db_host"
    db_port = "your_db_port"
    db_name = "your_db_name"
    table_name = "intrinio_ticker_prices"

    # Create a connection to the PostgreSQL database
    engine = create_engine(
        f"postgresql://{db_user}:{db_password}@{db_host}:{db_port}/{db_name}"
    )

    # Ensure the DataFrame columns match the target table columns
    all_filtered_data.columns = [col.lower() for col in all_filtered_data.columns]
    all_filtered_data.rename(
        columns={
            "security_id": "security_id",
            "company_id": "company_id",
            "name": "name",
            "cik": "cik",
            "ticker": "ticker",
            "figi": "figi",
            "composite_figi": "composite_figi",
            "comp_ticker": "comp_ticker",
            "exch_ticker": "exch_ticker",
            "date": "date",
            "type": "type",
            "frequency": "frequency",
            "open": "open",
            "high": "high",
            "low": "low",
            "close": "close",
            "volume": "volume",
            "adj_open": "adj_open",
            "adj_high": "adj_high",
            "adj_low": "adj_low",
            "adj_close": "adj_close",
            "adj_volume": "adj_volume",
            "adj_factor": "adj_factor",
            "ex_dividend": "ex_dividend",
            "split_ratio": "split_ratio",
            "change": "change",
            "percent_change": "percent_change",
            "fifty_two_week_high": "fifty_two_week_high",
            "fifty_two_week_low": "fifty_two_week_low",
        },
        inplace=True,
    )

    # Store the filtered data in the PostgreSQL table
    all_filtered_data.to_sql(table_name, engine, if_exists="append", index=False)

    # Print and log the total number of records inserted
    total_records = len(all_filtered_data)
    print(f"Total records inserted: {total_records}")
    log_file.write(f"Total records inserted: {total_records}\n")
