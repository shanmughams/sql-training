import asyncio
import os
import time

import aiohttp

from core.logger import logger

strapi_etf_ticker_url = f"{os.environ['STRAPI_URL']}/api/etf-tickers"
strapi_etf_ticker_metadata_url = f"{os.environ['STRAPI_URL']}/api/etf-tickers-metadata"

# Environment variables
INTRINIO_API_KEY = os.getenv("INTRINIO_API_KEY")
STRAPI_URL = os.getenv("STRAPI_URL")  # e.g., http://localhost:1337/api/ticker-details

headers = {
    "Authorization": f"Bearer {INTRINIO_API_KEY}",
    "Content-Type": "application/json",
}

symbols = [
    "CLVT",
    "CLVT",
    "BRSP",
    "GEO",
    "ULCC",
    "ULCC",
    "ZD",
    "CSGP",
    "ULCC",
    "WYNN",
    "ZD",
    "CI",
    "CI",
    "ALGT",
    "TMO",
    "WYNN",
    "SEE",
    "IPG",
    "LSCC",
    "ULCC",
    "RMD",
    "CMCSA",
    "HRI",
    "TEX",
    "HRI",
    "ADSK",
    "BHE",
    "HPQ",
    "BHE",
    "BHE",
    "BHE",
    "HPQ",
    "HPQ",
    "LOW",
    "TER",
    "CNC",
    "ILMN",
    "LOW",
    "HPP",
    "WHR",
    "ABT",
    "TYL",
    "TGT",
    "AGYS",
    "AGYS",
    "AGYS",
    "TYL",
    "CI",
    "MMM",
    "ZI",
    "VRSN",
    "KDP",
    "KDP",
    "KDP",
    "KDP",
    "KDP",
    "KDP",
    "WHR",
    "ADSK",
    "LVS",
    "TEX",
    "CSX",
    "CRI",
    "WHR",
    "LVS",
    "ADSK",
    "CSX",
    "TRU",
    "TRU",
    "LVS",
    "CSX",
    "MGNI",
    "RYN",
    "TRUP",
    "CMCSA",
    "INTC",
    "UNH",
    "SHEN",
    "CMCSA",
    "INTC",
    "IMO",
    "IMO",
    "DNB",
    "KR",
    "PLNT",
    "DNB",
    "EBAY",
    "EBAY",
    "HPE",
    "HPE",
    "HPE",
    "HPE",
    "UNH",
    "UNH",
    "PARA",
    "GXO",
    "PARA",
    "POST",
    "PLNT",
    "PANW",
    "MA",
    "DIS",
    "DIS",
    "SSP",
    "SSP",
    "WRB",
    "V",
    "SJW",
    "VTRS",
    "VTRS",
    "VTRS",
    "VTRS",
    "X",
    "X",
    "X",
    "VTRS",
    "VTRS",
    "VTRS",
    "FLT",
    "MRNA",
    "DKL",
    "DOCU",
    "NSSC",
    "DOCU",
    "DOCU",
    "PODD",
    "DOCU",
    "NSSC",
    "DOCU",
    "PFE",
    "OLPX",
    "M",
    "M",
    "M",
    "M",
    "M",
    "M",
    "M",
    "M",
    "CI",
    "DRVN",
    "LRN",
    "CSCO",
    "CSCO",
    "LSCC",
    "APTV",
    "LSCC",
    "ZI",
    "ZI",
    "UAL",
    "MAA",
    "WHR",
    "JNJ",
    "UAL",
    "GM",
    "LSCC",
    "OTIS",
    "TMHC",
    "JNJ",
    "TMHC",
    "TRU",
    "TRU",
    "UAL",
    "ABT",
    "KO",
    "UAL",
    "GATX",
    "GXO",
    "LW",
    "TRU",
    "JNJ",
    "EQR",
    "BOX",
    "PLNT",
    "OTIS",
    "LW",
    "TRU",
    "UAA",
    "ABT",
    "NBR",
    "NBR",
    "NBR",
    "ENPH",
    "KO",
    "EVRG",
    "ENPH",
    "ENPH",
    "GM",
    "OTIS",
    "ANIP",
    "AKAM",
    "AKAM",
    "CNXC",
    "ENPH",
    "PANW",
    "MSCI",
    "MSCI",
    "LW",
    "MASI",
]
# unique_symbols = set(symbols)

symbols = symbols * 10


async def fetch_ticker_details(session, symbol: str) -> dict:
    url = f"https://api-v2.intrinio.com/securities/{symbol}"
    try:
        async with session.get(url, headers=headers) as response:
            response.raise_for_status()
            data = await response.json()
            logger.info(f"Fetched data for {symbol}: {data}")
            return data
    except aiohttp.ClientError as e:
        logger.error(f"Error fetching data for {symbol}: {e}")
        return {"symbol": symbol, "error": str(e)}


# async def store_to_strapi(data: dict):
#     try:
#         async with aiohttp.ClientSession() as session:
#             async with session.post(STRAPI_URL, json=data) as response:
#                 response.raise_for_status()
#                 logger.info(f"Stored data for {data['symbol']} in Strapi")
#                 return await response.json()
#     except aiohttp.ClientError as e:
#         logger.error(f"Error storing data for {data['symbol']} in Strapi: {e}")
#         return {"symbol": data['symbol'], "error": str(e)}
#


async def fetch_all_ticker_details():
    async with aiohttp.ClientSession(headers=headers) as session:
        tasks = [fetch_ticker_details(session, symbol) for symbol in symbols]
        results = await asyncio.gather(*tasks)
        return results


async def get_ticker_prices_from_intrinio():
    start_time_ticker = time.time()
    metadata = await fetch_all_ticker_details()
    end_time_ticker = time.time()
    count = len(metadata)
    print(
        f"Retrieved {len(metadata)} records from Intrinio "
        f"Collection in {end_time_ticker - start_time_ticker} seconds"
    )

    # tasks = [store_to_strapi(data) for data in metadata]
    # results = await asyncio.gather(*tasks)
    return count


if __name__ == "__main__":
    asyncio.run(get_ticker_prices_from_intrinio())
