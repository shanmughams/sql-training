import redis

# Initialize Redis connection
redis_host = "localhost"  # Change to your Redis server host
redis_port = 6379  # Default Redis port
redis_client = redis.StrictRedis(host=redis_host, port=redis_port, db=0)

# Redis set name
ticker_set_name = "tickers"


def save_ticker_details(ticker_details):
    ticker_symbol = ticker_details["ticker"]

    # Check if ticker symbol is present in Redis set
    if redis_client.sismember(ticker_set_name, ticker_symbol):
        print(f"{ticker_symbol} is already present in the cache.")
        return
    else:
        print(f"Successfully saved {ticker_symbol} to the database.")
        # Add ticker symbol to Redis set
        redis_client.sadd(ticker_set_name, ticker_symbol)
    # Save to Strapi DB
    # response = requests.post(strapi_url, json=ticker_details, headers=strapi_headers)
    #
    # if response.status_code == 200:
    #     print(f"Successfully saved {ticker_symbol} to the database.")
    #     # Add ticker symbol to Redis set
    #     redis_client.sadd(ticker_set_name, ticker_symbol)
    # else:
    #     print(f"Failed to save {ticker_symbol} to the database. Status code: {response.status_code}, Error: {response.text}")


# Example usage
ticker_details = {
    "ticker": "AAPL",
    "name": "Apple Inc.",
    "exchange": "NASDAQ",
    # Add other fields as needed
}

save_ticker_details(ticker_details)
