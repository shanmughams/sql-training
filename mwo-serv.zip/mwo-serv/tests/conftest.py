import asyncio
from asyncio import AbstractEventLoop
from typing import Any, AsyncGenerator, Generator
from unittest.mock import AsyncMock, MagicMock, Mock, patch

import pytest
from httpx import AsyncClient
from sqlalchemy import StaticPool
from sqlalchemy.ext.asyncio import AsyncSession, async_sessionmaker, create_async_engine

from db.session import Base

# Mock settings
from main import app


@pytest.fixture(scope="session")
async def async_client() -> AsyncGenerator[AsyncClient, Any]:
    async with AsyncClient(app=app, base_url="http://testserver") as client:
        yield client


@pytest.fixture(scope="module")
def event_loop() -> Generator[AbstractEventLoop, Any, None]:
    loop = asyncio.new_event_loop()
    yield loop
    loop.close()


@pytest.fixture
def mock_service() -> AsyncMock:
    mock_service = AsyncMock()
    return mock_service


@pytest.fixture()
def redis_cache_backend() -> AsyncMock:
    redis_cache_backend = AsyncMock()
    return redis_cache_backend


@pytest.fixture()
def settings() -> Generator[MagicMock | AsyncMock, Any, None]:
    with patch(
        "api.v1.endpoints.intrinio_endpoints.settings", new_callable=Mock
    ) as settings:
        yield settings


@pytest.fixture()
def httpx_get() -> Generator[MagicMock | AsyncMock, Any, None]:
    with patch("httpx.AsyncClient.get", new_callable=AsyncMock) as httpx_get:
        yield httpx_get


@pytest.fixture(autouse=True)
def depends() -> Generator[Mock, Any, None]:
    with patch("fastapi.Depends", new_callable=Mock) as depends:
        yield depends


# Mocking database session
@pytest.fixture(scope="function")
async def db_session() -> AsyncGenerator[AsyncSession, Any]:
    engine = create_async_engine(
        "sqlite+aiosqlite:///:memory:",
        connect_args={"check_same_thread": False},
        poolclass=StaticPool,
    )
    async_session_local = async_sessionmaker(bind=engine, class_=AsyncSession)
    async with engine.begin() as conn:
        await conn.run_sync(Base.metadata.create_all)
    async with async_session_local() as session:
        yield session
    await session.close()


@pytest.fixture
def async_mock_session() -> AsyncMock:
    async_session = AsyncMock(spec=AsyncSession)
    return async_session
