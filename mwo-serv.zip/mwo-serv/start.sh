#!/bin/bash
# Print message
echo "Starting setup..."
# Run Alembic migrations
./wait-for-it.sh mwo-db:5432 -t 60 -- alembic upgrade head
# Start the application with Uvicorn
./wait-for-it.sh mwo-db:5432 -t 60 -- uvicorn main:app --host 0.0.0.0 --port 8000 --reload
