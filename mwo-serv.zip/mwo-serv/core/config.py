import os
from datetime import datetime

from pydantic_settings import BaseSettings

ROOT_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
LOGS_DIR = os.path.join(ROOT_DIR, "logs")

# Create the logs directory if it doesn't exist
os.makedirs(LOGS_DIR, exist_ok=True)


class Settings(BaseSettings):
    database_url: str = os.environ["DATABASE_URL"]
    strapi_url: str = f"{os.environ["STRAPI_URL"]}/api"
    echo_sql: bool = True
    test: bool = False
    project_name: str = "Backend Demo"
    oauth_token_secret: str = "my_dev_secret"
    log_level: str = "INFO"
    docs_url: str = "/docs"
    redoc_url: str = "/redoc"
    openapi_url: str = "/openapi.json"
    root_path: str = "/api/v1"
    openapi_version: str = "3.0.2"
    openapi_title: str = "Backend API Demo"
    description: str = "Backend Demo API Demo Description"
    project_version: str = "1.0.0"
    log_dir: str = os.path.join(
        LOGS_DIR, f"app-{datetime.now().strftime('%Y-%m-%d_%H%M%S')}.log"
    )
    wait_for_5_sec: int = 5
    strapi_etf_market_indices_endpoint: str = f"{strapi_url}/etf-market-indices"
    strapi_ticker_price_bulk_insert_endpoint: str = (
        f"{strapi_url}/intrinio-ticker-price-bulk-insert"
    )
    intrinio_api_key: str = os.environ["INTRINIO_API_KEY"]
    tradesmith_username: str = os.environ["TRADESMITH_USERNAME"]
    tradesmith_password: str = os.environ["TRADESMITH_PASSWORD"]
    strapi_signals_endpoint: str = f"{strapi_url}/signals"
    strapi_signals_bulk_get_on_buy_threshold_endpoint: str = (
        f"{strapi_url}/signal-bulk-get-on-buy-threshold"
    )
    strapi_ticker_price_endpoint: str = f"{strapi_url}/intrinio-ticker-prices"
    strapi_ticker_detail_endpoint: str = f"{strapi_url}/intrinio-ticker-details"
    strapi_ticker_detail_bulk_insert_endpoint: str = (
        f"{strapi_url}/intrinio-ticker-detail-bulk-insert"
    )
    strapi_ticker_detail_bulk_get_endpoint: str = (
        f"{strapi_url}/intrinio-ticker-detail-bulk-get"
    )
    strapi_api_key: str = os.environ["STRAPI_TOKEN"]


settings = Settings()
