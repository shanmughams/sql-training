import logging
import sys

from core.config import settings

# get Logger
logger = logging.getLogger()

# Create Formatter
formatter = logging.Formatter(
    fmt=" AccessTime: %(asctime)s - LevelName: %(levelname)s - Message:%(message)s",
    datefmt="%Y-%m-%d %H:%M:%S",
)

# stream handlers
stream_handler = logging.StreamHandler(sys.stdout)
# file handlers
file_handler = logging.FileHandler(filename=settings.log_dir, encoding="utf-8")

# Set Formatters
stream_handler.setFormatter(formatter)
file_handler.setFormatter(formatter)

# Set Handler
logger.handlers = [stream_handler, file_handler]

# Set Log Level
logger.setLevel(logging.DEBUG if settings.log_level == "DEBUG" else logging.INFO)
