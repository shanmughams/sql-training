from typing import Any, Generic, Sequence, Type, TypeVar

from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy.future import select

from db.session import Base
from repositories.irepository import IGenericRepository

T = TypeVar("T", bound=Base)


class GenericRepository(IGenericRepository[T], Generic[T]):
    def __init__(self, db_session: AsyncSession, model: Type[T]):
        self.db_session = db_session
        self.model = model

    async def get_all(self, skip: int, limit: int) -> Sequence[Any]:
        result = await self.db_session.execute(
            select(self.model).offset(skip).limit(limit)
        )
        return result.scalars().unique().all()

    async def get_by_id(self, item_id: int) -> Any | None:
        result = await self.db_session.execute(
            select(self.model).filter(self.model.id == item_id)
        )
        return result.unique().scalar_one_or_none()

    async def create(self, item: T) -> T:
        self.db_session.add(item)
        await self.db_session.commit()
        await self.db_session.refresh(item)
        return item

    async def update(self, item_id: int, item_data: dict) -> T | None:
        item = await self.db_session.get(self.model, item_id)
        if item:
            for key, value in item_data.items():
                setattr(item, key, value)
            await self.db_session.commit()
            await self.db_session.refresh(item)
        return item

    async def delete(self, item_id: int) -> None:
        item = await self.db_session.get(self.model, item_id)
        if item:
            await self.db_session.delete(item)
            await self.db_session.commit()


class Repository(GenericRepository):
    def __init__(self, db_session: AsyncSession, model: Base):
        super().__init__(db_session, model)
