from typing import Any, Generic, Sequence, TypeVar

from repositories.repository import GenericRepository
from services.iservice import IGenericService

# Define a type variable for models

T = TypeVar("T")


class GenericService(IGenericService[T], Generic[T]):

    def __init__(self, repository: "GenericRepository[T]"):
        self.repository = repository

    async def get_all(self, skip: int, limit: int) -> Sequence[Any]:
        return await self.repository.get_all(skip, limit)

    async def get_by_id(self, item_id: int) -> Any | None:
        return await self.repository.get_by_id(item_id)

    async def create(self, item: T) -> T:
        return await self.repository.create(item)

    async def update(self, item_id: int, item_data: dict) -> T | None:
        return await self.repository.update(item_id, item_data)

    async def delete(self, item_id: int) -> None:
        return await self.repository.delete(item_id)


class Service(GenericService):
    def __init__(self, repository: "GenericRepository[T]"):
        super().__init__(repository)
        self.repository = repository
