import asyncio
import os
import time
import zipfile
from datetime import datetime
from pathlib import Path
from typing import Any, Dict, List, Tuple

import aiofiles
import aiofiles.os
import aiohttp
import httpx
from dateutil.relativedelta import relativedelta
from starlette import status

from core.config import settings
from core.logger import logger
from schemas.market_index_schema import InternalServerError
from services.strapi_service import bulk_insert_ticker_details, bulk_insert_ticker_price
from utils.constants import (
    INTRINIO_API_MAX_RETRIES,
    INTRINIO_API_RATE_LIMIT_SLEEP_SECONDS,
    INTRINIO_BULK_DOWNLOAD_URL,
    INTRINIO_SECURITY_DETAILS_URL,
    INTRINIO_TICKER_DETAILS_URL,
)
from utils.rsi_signal_cron_summary_report import cron_report
from utils.rsi_signals_util import prepare_filter
from utils.util import get_resource_dir, get_utc_time_str


async def fetch_zip_name_urls() -> List[Tuple[str, str]]:
    """
    Fetch ZIP URLs from the Intrinio Bulk Download API.
    @returns: List
    """
    try:
        async with aiohttp.ClientSession() as session:
            async with session.get(
                INTRINIO_BULK_DOWNLOAD_URL,
                headers={"Authorization": f"Bearer {settings.intrinio_api_key}"},
            ) as response:
                response.raise_for_status()
                links = []
                data = await response.json()
                # Extract the URLs from the API response
                for _ in data["bulk_downloads"]:
                    if _["name"] == "US Stock Prices, 5 years":
                        links.extend(_["links"])
                        zip_name_urls = [(link["name"], link["url"]) for link in links]
                return zip_name_urls
    except Exception as e:
        data = InternalServerError(data=f"{e}").json()
        logger.error(data)
        return data


async def fetch_securities_from_intrinio(url: str, code: str) -> Any:
    """
    Calls Intrinio URL to get the securities, awaits for one min if too many requests (i.e rate limiting imposed)
    :param url:
    :type url:
    :param code:
    :type code:
    :return:
    :rtype:
    """
    data = None
    try:
        for attempt in range(INTRINIO_API_MAX_RETRIES):
            logger.info(f"Calling API URL - {url}, try ")
            async with httpx.AsyncClient() as client:
                response = await client.get(url)
                status_code = response.status_code
                if status_code == status.HTTP_200_OK:
                    data = response.json()
                    break
                elif status_code == status.HTTP_429_TOO_MANY_REQUESTS:
                    logger.info(
                        f"Rate limited, too Many requests in One min. "
                        f"Retrying after {INTRINIO_API_RATE_LIMIT_SLEEP_SECONDS} seconds for symbol code - {code}"
                    )
                    await asyncio.sleep(INTRINIO_API_RATE_LIMIT_SLEEP_SECONDS)
                    continue
                response.raise_for_status()
    except Exception as e:
        logger.error(f"Error getting ticker details: {e}")
    return data


async def fetch_all_ticker_details_from_intrinio(unique_symbols: List) -> Any:
    headers = {
        "Authorization": f"Bearer {settings.intrinio_api_key}",
        "Content-Type": "application/json",
    }
    logger.info(
        f"Going to fetch ticker details for the  tickers(# {[len(unique_symbols)]}) : {unique_symbols}"
    )
    async with aiohttp.ClientSession(headers=headers) as session:
        tasks = [fetch_ticker_detail(session, symbol) for symbol in unique_symbols]
        results = await asyncio.gather(*tasks)
        return results


async def fetch_ticker_detail(session: aiohttp.ClientSession, symbol: str) -> dict:
    data = {}
    url = INTRINIO_SECURITY_DETAILS_URL.format(
        ticker=symbol, api_key=settings.intrinio_api_key
    )
    try:
        async with session.get(url) as response:
            response.raise_for_status()
            data = await response.json()
            logger.debug(f"Fetched ticker data for {symbol}: {data.get("name", "")}")
            return data
    except aiohttp.ClientError as e:
        logger.error(
            f"Error fetching ticker data for {symbol}: {str(e)}", exc_info=True
        )
        return data


async def fetch_ticker_details_for_symbol_code(
    symbol_code: str, existing_tickers: Dict[str, list]
) -> float:
    """
    Loads the Security details for the symbol code passed
    :param symbol_code:
    :type symbol_code:
    :param existing_tickers:
    :type existing_tickers:
    :return:
    :rtype:
    """
    total_time_taken: float = 0
    next_page = None
    i = 1
    logger.info(
        f"Loading Ticker Details for symbol code [{symbol_code}] from Intrinio "
    )
    while True:
        load_start_time = time.time()
        url = INTRINIO_TICKER_DETAILS_URL.format(
            code=symbol_code, api_key=settings.intrinio_api_key
        )
        if next_page:
            url += f"&next_page={next_page}"

        data = await fetch_securities_from_intrinio(url, symbol_code)
        if data is None or data["securities"] is None:
            logger.info(f"No data for symbol code : [{symbol_code}]")
            break
        else:
            logger.info(
                f"Total records fetched for code : [{symbol_code}] is : [{len(data['securities'])}]"
            )
        data_save_start_time = time.time()
        new_ticker_inserted_count = await bulk_insert_ticker_details(
            data["securities"], existing_tickers
        )
        logger.info(f"New tickers inserted - [{new_ticker_inserted_count}]")
        data_save_end_time = time.time()
        load_end_time = data_save_end_time
        data_save_elapsed_time = data_save_end_time - data_save_start_time
        elapsed_time = load_end_time - load_start_time
        total_time_taken += elapsed_time
        logger.info(
            f"Processed symbol code : [{symbol_code}], page run : [{i}] in [{elapsed_time:.2f}] seconds"
        )
        next_page = data.get("next_page")

        if not next_page:
            await sleep_for_api_rate_limit_per_min(data_save_elapsed_time)
            break
        logger.info(
            f"Run [{i}] finished for symbol code : [{symbol_code}], going to fetch next page : [{next_page}]"
        )
        i += 1
        await sleep_for_api_rate_limit_per_min(data_save_elapsed_time)
    return total_time_taken


async def sleep_for_api_rate_limit_per_min(data_save_elapsed_time: float) -> None:
    """
    Sleeps for the remaining time on 1 min - data_save_elapsed_time, just to make sure for Bulk pagination response API
    for intrinio, only one req/min can be fired. once fired need to sleep for a min.
    :param data_save_elapsed_time:
    :type data_save_elapsed_time:
    :return:
    :rtype:
    """
    try:
        if data_save_elapsed_time < 60:
            time_to_sleep = 60 - data_save_elapsed_time
            logger.info(
                f"Asyncio Sleeping for {time_to_sleep:.2f} seconds on Max API requests with large pagination values"
            )
            await asyncio.sleep(time_to_sleep)
        else:
            logger.info(
                f"No sleep needed as data_save_elapsed_time - {data_save_elapsed_time} is more than one minute"
            )
    except Exception as e:
        logger.error(f"An error occurred during sleep: {str(e)}", exc_info=True)


async def download_zip(session: Any, name: str, url: str, download_path: str) -> str:
    """
    Download Zip
    @param session: aiohttp session
    @param name: ZIP Name
    @param url: ZIP URL
    @param download_path: Path to download zip
    @return: Path to downloaded zip
    """
    async with session.get(url) as response:
        response.raise_for_status()
        zip_path = os.path.join(download_path, name)
        async with aiofiles.open(zip_path, "wb") as f:
            await f.write(await response.read())
        logger.info(f"Downloaded {name}")
        return zip_path


async def unzip_and_delete_file(zip_path: str, extract_to: str) -> Any:
    """
    Unzip And Delete a File
    @param zip_path: Path to zip file
    @param extract_to: Path to extract zip file
    @return: Any
    """
    try:
        with zipfile.ZipFile(zip_path) as z:
            z.extractall(extract_to)
        logger.info(f"Extracted {zip_path} to {extract_to}")
        os.remove(zip_path)
        logger.info(f"Deleted {zip_path}")
    except Exception as e:
        logger.error(f"Error extracting {zip_path}: {e}")


async def download_and_process_zip(
    zip_urls: Any, download_path: str, extract_to: str
) -> Any:
    """
    Download And Process Zip
    :param zip_urls: any
    :param download_path: str
    :param extract_to: str
    :return: any
    """
    async with aiohttp.ClientSession() as session:
        download_tasks = []
        for name, url in zip_urls:
            task = asyncio.create_task(download_zip(session, name, url, download_path))
            download_tasks.append(task)
        zip_paths = await asyncio.gather(*download_tasks)

        unzip_tasks = []
        for zip_path in zip_paths:
            task = asyncio.create_task(unzip_and_delete_file(zip_path, extract_to))
            unzip_tasks.append(task)
        await asyncio.gather(*unzip_tasks)


async def get_ticker_prices_from_intrinio(symbol_ids: set) -> Dict[str, int]:
    """
    Gets the Intrinio ticker details and save thru strapi
    :param symbol_ids:
    :type symbol_ids:
    :return:
    :rtype:
    """
    count_dict: Dict[str, int] = dict()
    start_date_100_months = (
        datetime.strptime(get_utc_time_str(date_time_format="%Y-%m-%d"), "%Y-%m-%d")
        - relativedelta(months=100)
    ).strftime("%Y-%m-%d")

    symbol_id_filter = prepare_filter(
        symbol_ids=list(symbol_ids), date=start_date_100_months
    )
    logger.info(f"symbol id filter {symbol_id_filter}")
    # Fetching Zip Urls From Bulk Download
    start_time = time.time()
    cron_report.set_ticker_price_download_start_time_formatted()
    zip_urls = await fetch_zip_name_urls()
    download_path = get_resource_dir()
    extract_to = get_resource_dir()
    # Create directories if they don't exist
    Path(download_path).mkdir(parents=True, exist_ok=True)
    Path(extract_to).mkdir(parents=True, exist_ok=True)
    # Download And Process Zip File
    await download_and_process_zip(zip_urls, download_path, extract_to)
    end_time = time.time()
    cron_report.ticker_price_download_success = True
    cron_report.set_ticker_price_download_end_time_formatted()
    cron_report.ticker_price_download_time_taken = end_time - start_time
    logger.info(
        msg=f"Total Time taken in Downloading Stock Zips and processing : {end_time - start_time} seconds"
    )
    # Inserting ticker price for new symbols
    if len(symbol_ids) > 0:
        new_symbol_inserted_count = await bulk_insert_ticker_price(
            filters=symbol_id_filter
        )
        count_dict["new_symbol_insert_count"] = new_symbol_inserted_count

    return count_dict
