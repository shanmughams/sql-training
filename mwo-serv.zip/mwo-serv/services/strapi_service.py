import asyncio
import os
from concurrent.futures import ThreadPoolExecutor
from datetime import datetime, timedelta
from typing import Any, AsyncGenerator, Dict, List, Tuple, Union

import aiohttp
import httpx
import pandas as pd
from dateutil.relativedelta import relativedelta
from starlette import status

from core.config import settings
from core.logger import logger
from schemas.market_index_schema import InternalServerError
from utils.constants import (
    ETF_MARKET_INDICES_CREATE_UPDATE_DATE_TIME_FORMAT,
    STRAPI_API_MAX_RETRIES,
    STRAPI_BULK_CHUNK_SIZE,
)
from utils.rsi_signals_util import get_unique_tickers, map_security_field
from utils.util import (
    get_resource_dir,
    get_strapi_headers,
    get_utc_time_str,
    is_non_empty,
    write_data_into_json,
)


async def find_ticker_prices_on_9_months(ticker: str, buy_date: str) -> Any:
    """
    Gets the Ticker symbol price details for last months of the buy date
    :param ticker:
    :type ticker:
    :param buy_date:
    :type buy_date:
    :return:
    :rtype:
    """
    data: List = []
    buy_date_obj = datetime.strptime(buy_date, "%m-%d-%Y")
    start_date_obj = buy_date_obj - relativedelta(months=9)
    start_date = start_date_obj.strftime("%Y-%m-%d")
    end_date = buy_date_obj.strftime("%Y-%m-%d")
    logger.info(
        f"Get ticker prices 9 months before the buy date - [{buy_date}] for ticker - [{ticker}],"
        f" start_date - [{start_date}], end_date - [{end_date}]"
    )
    async with httpx.AsyncClient() as client:
        try:
            api_params = {
                "sort": "DATE:desc",
                "pagination[pageSize]": "100",
                "filters[TICKER][$eq]": ticker,
                "filters[DATE][$gte]": start_date,
                "filters[DATE][$lte]": end_date,
            }
            strapi_api_headers = get_strapi_headers()
            response = await client.get(
                url=settings.strapi_ticker_price_endpoint,
                headers=strapi_api_headers,
                params=api_params,
            )
            if response.status_code == status.HTTP_200_OK:
                data = response.json().get("data", [])
            else:
                logger.error(
                    f"Error in getting Ticker price from strapi endpoint status Code: {response.status_code}"
                )
        except Exception as e:
            error_message = f"Error in getting ticker price information for [{ticker}] from strapi: {e}"
            logger.error(error_message)
            raise Exception(error_message)
        return data


async def get_all_recent_sell_signals() -> List[Dict]:
    """
    Get signals from strapi endpoint.
    :return: List of signals.
    """
    api_params: Dict[str, Any] = {
        "sort": "sell_date:asc",
        "pagination[pageSize]": str(100),
        "pagination[page]": str(1),
        "filters[sell_date][$notNull]": True,
    }
    strapi_url: Union[str, None] = settings.strapi_signals_endpoint
    signal_data: List = []
    retry_count = 0
    timeout = httpx.Timeout(5.0, connect=5.0)
    async with httpx.AsyncClient(timeout=timeout) as client:
        while strapi_url and retry_count < STRAPI_API_MAX_RETRIES:
            headers = get_strapi_headers()
            try:
                response = await client.get(
                    url=strapi_url,
                    params=api_params,
                    headers=headers,
                )
                if response.status_code == status.HTTP_200_OK:
                    data = response.json().get("data", [])
                    meta = response.json().get("meta", [])

                    if data:
                        for item in data:
                            signal_data.append(item)
                        logger.info(
                            f"Total signals received  :  [{len(signal_data)}], "
                            f"Overall signals count - [{len(signal_data)}]"
                        )
                    elif not data:
                        logger.info(
                            f"No Signals hitting where Sell Date Not NUll. API status code: {response.status_code}"
                        )
                    if meta:
                        pagination = meta.get("pagination", {})
                        if pagination and pagination.get("page") < pagination.get(
                            "pageCount"
                        ):
                            api_params["pagination[page]"] = pagination["page"] + 1
                        else:
                            strapi_url = None
                    logger.debug(f"Fetched all pages {pagination.get('pageCount')}")
                else:
                    logger.error(
                        f"Error getting signals from strapi endpoint status Code: {response.status_code}"
                    )
                    break

            except (httpx.RequestError, httpx.HTTPStatusError) as e:
                logger.error(
                    f"Error in getting signals where Sell Date Not NUll from strapi: {e}"
                )
                retry_count += 1
                if retry_count >= STRAPI_API_MAX_RETRIES:
                    logger.error(
                        f"Exceeded maximum retry attempts: {STRAPI_API_MAX_RETRIES}"
                    )
                    break
            except Exception as e:
                logger.error(
                    f"Error in getting signals where Sell Date Not NUll from strapi: {e}"
                )
                break

        return signal_data


async def get_all_open_buys_signals() -> List[Dict]:
    """
    Get signals from strapi endpoint.
    :return: List of signals.
    """
    logger.info("Getting All open buys signal")
    five_days_ago = (datetime.now() - timedelta(days=5)).strftime("%Y-%m-%d")
    api_params: Dict[str, Any] = {
        "sort": "buy_date:asc",
        "pagination[pageSize]": str(100),
        "pagination[page]": str(1),
        "filters[$or][0][$and][0][buy_rsi_threshold][$eq]": 30,
        "filters[$or][0][$and][1][buy_date][$gte]": "2024-06-16",
        "filters[$or][0][$and][2][sell_date][$null]": True,
        "filters[$or][1][sell_date][$gte]": five_days_ago,
    }
    strapi_url: Union[str, None] = settings.strapi_signals_endpoint
    signal_data: List = []
    strapi_api_headers = get_strapi_headers()
    retry_count = 0
    timeout = httpx.Timeout(5.0, connect=5.0)
    async with httpx.AsyncClient(timeout=timeout) as client:
        while strapi_url and retry_count < STRAPI_API_MAX_RETRIES:
            try:
                response = await client.get(
                    url=strapi_url,
                    headers=strapi_api_headers,
                    params=api_params,
                )
                if response.status_code == status.HTTP_200_OK:
                    data = response.json().get("data", [])
                    meta = response.json().get("meta", [])

                    if data:
                        for item in data:
                            signal_data.append(item)
                        logger.info(
                            f"Total Buys signals received count :  [{len(signal_data)}], "
                            f"Overall signals count - [{len(signal_data)}]"
                        )
                    elif not data:
                        logger.error(
                            f"No Signals on getting open buys signal. API status code: {response.status_code}"
                        )
                    if meta:
                        pagination = meta.get("pagination", {})
                        if pagination and pagination.get("page") < pagination.get(
                            "pageCount"
                        ):
                            api_params["pagination[page]"] = pagination["page"] + 1
                        else:
                            strapi_url = None
                    logger.debug(f"Fetched all pages {pagination.get('pageCount')}")
                else:
                    logger.error(
                        f"Error getting signals from strapi endpoint status Code: {response.status_code}"
                    )
                    break
            except (httpx.RequestError, httpx.HTTPStatusError) as e:
                logger.error(f"Error in getting All open buys signal from strapi: {e}")
                retry_count += 1
                if retry_count >= STRAPI_API_MAX_RETRIES:
                    logger.error(
                        f"Exceeded maximum retry attempts: {STRAPI_API_MAX_RETRIES}"
                    )
                    break
            except Exception as e:
                logger.error(f"Error in getting All open buys signal from strapi: {e}")
                break
        return signal_data


async def find_ticker_price_on_days_sorted(ticker: str, days_to_fetch: int) -> Any:
    """
    Gets the ticker price for the mentioned dates
    :param ticker:
    :type ticker:
    :param days_to_fetch:
    :type days_to_fetch:
    :return:
    :rtype:
    """
    data: List = []
    logger.info(f"ticker - {ticker}, days_to_fetch - {days_to_fetch}")
    async with httpx.AsyncClient() as client:
        try:
            params = {
                "sort": "DATE:desc",
                "pagination[limit]": str(days_to_fetch),
                "filters[TICKER][$eq]": ticker,
            }
            strapi_api_headers = get_strapi_headers()
            response = await client.get(
                url=settings.strapi_ticker_price_endpoint,
                headers=strapi_api_headers,
                params=params,
            )
            if response.status_code == status.HTTP_200_OK:
                data = response.json().get("data", [])
                if not data:
                    logger.info(
                        f"Signals list is coming empty status code: {response.status_code}"
                    )
            else:
                logger.info(
                    f"Error getting signals from strapi endpoint status Code: {response.status_code}"
                )
        except Exception as e:
            logger.error(f"Error in getting ticker price from strapi: {e}")
        return data


async def find_signal_by_transaction_id(transaction_id: int) -> Dict:
    """
    Find Signals By Transaction Id
    @param: transaction_id: int.
    """
    logger.info(f"Getting signal for a txn id - [{transaction_id}] ")
    rsi_signal: Dict = dict()
    async with httpx.AsyncClient() as client:
        try:
            params = {"filters[transaction_id][$eq]": transaction_id}
            strapi_api_headers = get_strapi_headers()
            response = await client.get(
                url=settings.strapi_signals_endpoint,
                headers=strapi_api_headers,
                params=params,
            )
            if response.status_code == status.HTTP_200_OK:
                data = response.json().get("data", [{}])
                if data:
                    rsi_signal = data[0]
                else:
                    logger.debug(
                        f"No signals matched with txn_id {transaction_id} status_code: {response.status_code}"
                    )
            else:
                logger.error(
                    f"Error getting signal from strapi status code {response.status_code}"
                )

        except Exception as e:
            logger.error(
                f"Error during getting signal record for transaction id: {transaction_id}: {e}"
            )
        return rsi_signal


async def find_signals_by_symbol_buy_date(signal: Dict) -> Dict:
    """
    Find Signals By Symbol Buy Date.
    @param: signal: Dict.
    @return: Dict with Signals.
    """
    logger.info("Get the signals with buy threshold")
    data: Dict = dict()
    async with httpx.AsyncClient() as client:
        try:
            symbol_id = signal.get("SymbolId")
            buy_date = signal.get("BuyDate")
            buy_rsi_threshold = signal.get("BuyRsiThreshold")
            strapi_api_headers = get_strapi_headers()
            params = {
                "filters[symbol_id][$eq]": symbol_id,
                "filters[buy_date][$eq]": buy_date,
                "filters[buy_rsi_threshold][$eq]": buy_rsi_threshold,
            }
            response = await client.get(
                url=settings.strapi_signals_endpoint,
                headers=strapi_api_headers,
                params=params,
            )
            if response.status_code == 200:
                data = response.json().get("data", [])
                if data:
                    return data[0]
                else:
                    logger.debug(f"No Signal matched with criteria {params}")
            else:
                logger.error(
                    f"Error in getting signal from strapi: {response.status_code}"
                )
        except Exception as e:
            logger.error(
                f"Error during in getting signals on the params {params} : {e}"
            )
        return data


async def get_last_update_date_from_signals() -> str | None:
    """
    Get last update date from strapi signals.
    @return: str
    """
    last_update_date = None
    async with httpx.AsyncClient() as client:
        try:
            api_params = {"sort": "update_date:desc", "pagination[limit]": "1"}
            strapi_api_headers = get_strapi_headers()
            response = await client.get(
                url=settings.strapi_signals_endpoint,
                headers=strapi_api_headers,
                params=api_params,
            )
            if response.status_code == status.HTTP_200_OK:
                data = response.json().get("data", [{}])
                if data:
                    attributes = data[0].get("attributes", "")
                    update_date = data[0].get("attributes", "").get("update_date", "")
                    if data and attributes and update_date:
                        last_update_date = update_date
                    else:
                        logger.error(
                            f"last_update_date: {last_update_date} status_code: {response.status_code}"
                        )
                else:
                    logger.warning("No Signals Records Found in strapi data")
            else:
                logger.error(
                    f"Error in getting last update date from strapi status code: {response.status_code}"
                )
        except Exception as e:
            logger.error(f"Error during in getting last_update_date: {e}")
        return last_update_date


# Function to update the fields to null asynchronously
async def clear_current_previous_buys(id: int) -> Dict:
    """

    :param id:
    :type id:
    :return:
    :rtype:
    """
    strapi_url = f"{settings.strapi_signals_endpoint}/{id}"
    headers = get_strapi_headers()
    payload = {"data": {"buy_signal": None, "buy_signal": None}}
    async with httpx.AsyncClient() as client:
        response = await client.put(url=strapi_url, headers=headers, json=payload)
        return response.json()


async def clear_current_previous_buy_signals_list(ids_to_update: Any) -> List:
    """
    Clears the signals for the current previous buy with None
    :param ids_to_update:
    :type ids_to_update:
    :return:
    :rtype:
    """
    tasks = [clear_current_previous_buys(id) for id in ids_to_update]
    results = await asyncio.gather(*tasks)
    return results


async def get_current_previous_buy_signals_set() -> dict:
    """

    :return:
    :rtype:
    """
    logger.info("Getting current previous buy signals")
    ids_to_update = []
    signals_list = []
    api_params: Dict[str, Any] = {
        "pagination[pageSize]": str(100),
        "pagination[page]": str(1),
        "filters[$or][0][buy_signal][$notNull]": True,
        "filters[$or][1][sell_signal][$notNull]": True,
        "fields[0]": "id",
        "fields[1]": "buy_signal",
        "fields[2]": "sell_signal",
    }
    strapi_api_headers = get_strapi_headers()
    async with httpx.AsyncClient() as client:
        while True:
            response = await client.get(
                settings.strapi_signals_endpoint,
                headers=strapi_api_headers,
                params=api_params,
            )
            response_data = response.json()
            data = response_data.get("data", [])
            for item in data:
                signal_info = {
                    "id": item["id"],
                    "buy_signal": item.get("attributes", {}).get(
                        "buy_signal"
                    ),
                    "sell_signal": item.get("attributes", {}).get(
                        "sell_signal"
                    ),
                }
                signals_list.append(signal_info)
                ids_to_update.append(item["id"])

            pagination = response_data.get("meta", {}).get("pagination", {})
            current_page = pagination.get("page", 1)
            page_count = pagination.get("pageCount", 1)

            if current_page >= page_count:
                break

            api_params["pagination[page]"] = str(current_page + 1)

    return {"ids_to_update": ids_to_update, "signals_list": signals_list}


async def reset_current_previous_buy_signals() -> None:
    """
    Gets the list of existing current and previous buy signals and reset to none
    :return:
    :rtype:
    """
    ids_to_update = await get_current_previous_buy_signals_set()

    if ids_to_update is None or len(ids_to_update) == 0:
        logger.info("No signals set with current or previous buys")
        return None

    ids_list = ids_to_update.get("ids_to_update")
    if is_non_empty(ids_list):
        results = await clear_current_previous_buy_signals_list(ids_list)
        logger.info(
            f"Total signals updated for current previous buys : [{len(results)}]"
        )
    else:
        logger.info("No signals set with current or previous buys")


async def get_rsi_signals_on_buy_threshold() -> List[Dict]:
    """
    Get signals from strapi endpoint.
    :return: List of signals.
    """
    api_params = {
        "sort": "buy_date:desc",
        "pagination[pageSize]": str(100),
        "pagination[page]": str(1),
        "filters[buy_rsi_threshold][$eq]": "30",
        "filters[buy_date][$gte]": "2024-06-16T00:00:00Z",
    }
    strapi_url: Union[str, None] = settings.strapi_signals_endpoint
    signal_data: List = []
    strapi_api_headers = get_strapi_headers()
    async with httpx.AsyncClient() as client:
        while strapi_url:
            try:
                response = await client.get(
                    url=strapi_url,
                    headers=strapi_api_headers,
                    params=api_params,
                )
                if response.status_code == status.HTTP_200_OK:
                    data = response.json().get("data", [])
                    meta = response.json().get("meta", [])

                    if data:
                        for item in data:
                            signal_data.append(item)
                        logger.info(
                            f"Total symbols received on Buy threshold(30) count :  [{len(signal_data)}], "
                            f"Overall Tickers count - [{len(signal_data)}]"
                        )
                    elif not data:
                        logger.error(
                            f"No Signals hitting buy threshold. API status code: {response.status_code}"
                        )
                    if meta:
                        pagination = meta.get("pagination", {})
                        if pagination and pagination.get("page") < pagination.get(
                            "pageCount"
                        ):
                            api_params["pagination[page]"] = pagination["page"] + 1
                        else:
                            strapi_url = None
                    logger.debug(f"Fetched all pages {pagination.get('pageCount')}")
                else:
                    logger.error(
                        f"Error getting signals from strapi endpoint status Code: {response.status_code}"
                    )
            except Exception as e:
                logger.error(
                    f"Error in getting signals on buy threshold from strapi: {e}"
                )

        return signal_data


async def get_rsi_signals_on_buy_threshold_bulk() -> List[Dict]:
    """
    Get signals from strapi endpoint.
    :return: List of signals.
    """
    buy_date: str = "2024-06-16T00:00:00Z"
    api_params = {
        "sort": "buy_date:desc",
        "limit": str(5000),
        "page": str(1),
        "filters[buy_rsi_threshold][$eq]": "30",
        "filters[buy_date][$gte]": buy_date,
    }
    strapi_url: Union[str, None] = (
        settings.strapi_signals_bulk_get_on_buy_threshold_endpoint
    )
    signal_data: List = []
    strapi_api_headers = get_strapi_headers()
    retry_count = 0
    timeout = httpx.Timeout(5.0, connect=5.0)

    async with httpx.AsyncClient(timeout=timeout) as client:
        while strapi_url and retry_count < STRAPI_API_MAX_RETRIES:
            try:
                response = await client.get(
                    url=strapi_url,
                    headers=strapi_api_headers,
                    params=api_params,
                )
                if response.status_code == status.HTTP_200_OK:
                    data = response.json().get("data", [])
                    meta = response.json().get("meta", [])

                    if data:
                        for item in data:
                            signal_data.append(item)
                        logger.info(
                            f"Total symbols with Buy threshold = 30 & buy_date [{buy_date}]: [{len(signal_data)}], "
                            f"Overall Tickers count : [{len(signal_data)}]"
                        )
                    elif not data:
                        logger.info(
                            f"No Signals hitting buy threshold. API status code: {response.status_code}"
                        )
                    if meta:
                        pagination = meta.get("pagination", {})
                        if pagination and pagination.get("page") < pagination.get(
                            "pageCount"
                        ):
                            api_params["page"] = pagination["page"] + 1
                            logger.info(
                                f"Fetching page - [{api_params["page"]}] on Buy threshold"
                            )
                        else:
                            strapi_url = None
                    logger.debug(f"Fetched all pages {pagination.get('pageCount')}")
                else:
                    logger.error(
                        f"Error getting signals from strapi endpoint status Code: {response.status_code}"
                    )
                    break
            except (httpx.RequestError, httpx.HTTPStatusError) as e:
                logger.error(
                    f"Error in getting signals on buy threshold from strapi: {e}"
                )
                retry_count += 1
                if retry_count >= STRAPI_API_MAX_RETRIES:
                    logger.error(
                        f"Exceeded maximum retry attempts in getting signals"
                        f" on buy threshold: {STRAPI_API_MAX_RETRIES}"
                    )
                    break
            except Exception as e:
                logger.error(
                    f"Error in getting signals on buy threshold from strapi: {e}"
                )
                break
        return signal_data


async def bulk_insert_unique_ticker_details(
    new_securities: List[Dict[str, Any]]
) -> Any:
    final_count = 0
    if new_securities is None or len(new_securities) == 0:
        return final_count

    chunked_lists = prepare_chunks_from_list(new_securities, STRAPI_BULK_CHUNK_SIZE)
    logger.info(f"Chunked Lists len : {len(chunked_lists)}")
    final_count = 0
    logger.info("Starting Bulk Insert Ticker Details..")
    try:
        count_list = await bulk_insert_strapi_ticker_detail(chunk_list=chunked_lists)
        logger.info(msg=f"{sum(count_list)} rows inserted")
        final_count += sum(count_list)
        return final_count

    except Exception as e:
        data = InternalServerError(data=f"{e}").json()
        logger.error(data)
        return data

    return final_count


async def bulk_insert_ticker_details(
    securities: List[Dict[str, Any]], existing_tickers: Dict[str, list]
) -> Any:
    """
    Bulk Insert Ticker Price
    @filters: dict
    @returns: dict
    """
    final_count = 0
    new_securities = get_unique_tickers(securities, existing_tickers)
    new_securities = map_security_field(new_securities)

    # Filter out the duplicates in the list of ticker prices fetched from intrinio after mapped to valid one
    # check for ticker and name, if not present add as unique_new_securities and handle
    seen = set()
    unique_new_securities = []
    for security in new_securities:
        ticker_name_pair = (security.get("ticker"), security.get("name"))
        if ticker_name_pair not in seen:
            seen.add(ticker_name_pair)
            unique_new_securities.append(security)

    new_securities = unique_new_securities

    if new_securities and len(new_securities) > 0:
        logger.info(
            f"After removing duplicates in current, current unique ticker details is : [{len(new_securities)}] "
            f" : [{new_securities}]"
        )
        chunked_lists = prepare_chunks_from_list(new_securities, STRAPI_BULK_CHUNK_SIZE)
        logger.info(f"Chunked Lists len : {len(chunked_lists)}")
        final_count = 0
        logger.info("Starting Bulk Insert Ticker Details..")
        try:
            count_list = await bulk_insert_strapi_ticker_detail(
                chunk_list=chunked_lists
            )
            logger.info(msg=f"{sum(count_list)} rows inserted")
            final_count += sum(count_list)
            return final_count

        except Exception as e:
            data = InternalServerError(data=f"{e}").json()
            logger.error(data)
            return data
    else:
        logger.info(
            "After removing duplicates in current, current unique ticker details is 0 "
        )
    return final_count


def prepare_chunks_from_list(
    list_to_chunk: List[Any], chunk_size: int
) -> List[List[Any]]:
    """Helper function to split a list into chunks of specified size."""
    return [
        list_to_chunk[i : i + chunk_size]
        for i in range(0, len(list_to_chunk), chunk_size)
    ]


async def bulk_insert_strapi_ticker_detail(chunk_list: Any) -> Any:
    """
    Bulk Insert Strapi Ticker detail
    @param chunk_list: list
    @return: any
    """
    tasks = []
    headers = get_strapi_headers()
    async with aiohttp.ClientSession(headers=headers) as session:
        for chunk in chunk_list:
            task = asyncio.create_task(post_ticker_detail_into_strapi(session, chunk))
            tasks.append(task)
        response = await asyncio.gather(*tasks)
        return response


async def post_ticker_detail_into_strapi(
    session: Any, ticker_details_dict: List[Dict[str, Any]]
) -> Dict:
    """
    Post-Ticker-detail to Strapi
    @param session: aiohttp session
    @param ticker_details_dict: dict
    @return: dict
    """
    # data_to_post = json.dumps(ticker_details_dict)
    # print(data_to_post)
    async with session.post(
        url=settings.strapi_ticker_detail_bulk_insert_endpoint, json=ticker_details_dict
    ) as response:
        response.raise_for_status()
        ticker_details = await response.json()
        return ticker_details


async def bulk_insert_ticker_price(filters: Dict) -> Any:
    """
    Bulk Insert Ticker Price
    @filters: dict
    @returns: dict
    """
    count_list: List = []
    final_count = 0
    logger.info("Bulk Insert Ticker Price - Start")
    try:
        start_time = get_utc_time_str(
            date_time_format=ETF_MARKET_INDICES_CREATE_UPDATE_DATE_TIME_FORMAT,
            extra_formatting=3,
        )
        async for chunk_list, filename in convert_csv_to_json_in_chunks(
            filters=filters
        ):
            count_list = await bulk_insert_strapi_ticker_price(chunk_list=chunk_list)
            logger.info(msg=f"{sum(count_list)} rows inserted from {filename}")
            final_count += sum(count_list)
            end_time = get_utc_time_str(
                date_time_format=ETF_MARKET_INDICES_CREATE_UPDATE_DATE_TIME_FORMAT,
                extra_formatting=3,
            )
        if not filters:
            write_data_into_json(
                data={
                    "status": True,
                    "count": str(final_count),
                    "start_time": start_time,
                    "end_time": end_time,
                }
            )
            logger.info(
                f"Seeding Intrinio Ticker price collection with {final_count} records Done"
            )
        return final_count
    except Exception as e:
        data = InternalServerError(data=f"{e}").json()
        logger.error(data)
        return data


async def bulk_insert_strapi_ticker_price(chunk_list: Any) -> Any:
    """
    Bulk Insert Strapi Ticker Price
    @param chunk_list: list
    @return: any
    """
    tasks = []
    headers = {
        "Authorization": f"Bearer {os.environ['STRAPI_TOKEN']}",
        "Content-Type": "application/json",
    }
    async with aiohttp.ClientSession(headers=headers) as session:
        for chunk in chunk_list:
            task = asyncio.create_task(post_ticker_price_into_strapi(session, chunk))
            tasks.append(task)
        response = await asyncio.gather(*tasks)
        return response


async def post_ticker_price_into_strapi(session: Any, data: dict) -> Dict:
    """
    Post-Ticker-Price to Strapi
    @param session: aiohttp session
    @param data: dict
    @return: dict
    """
    async with session.post(
        settings.strapi_ticker_price_bulk_insert_endpoint,
        json=data,
    ) as response:
        response.raise_for_status()
        data = await response.json()
        return data


async def convert_csv_to_json_in_chunks(filters: Dict) -> AsyncGenerator:
    """
    Convert Csv to Json In Chunks
    @param filters: Dict[str, str]
    @return: AsyncGenerator
    """
    CSV_DIR = get_resource_dir()
    tasks = []
    for filename in os.listdir(CSV_DIR):
        if filename.startswith("stock_prices") and filename.endswith(".csv"):
            filepath = os.path.join(CSV_DIR, filename)
            tasks.append(read_csv_in_chunks(filepath, STRAPI_BULK_CHUNK_SIZE, filters))
    for task in asyncio.as_completed(tasks):
        chunk_list, filename = await task
        if chunk_list:
            yield chunk_list, filename


async def read_csv_in_chunks(
    filename: str, chunk_size: int, filters: Dict[str, str]
) -> Tuple[List[Dict], str]:
    """
    Read Csv In Chunks
    @param filename: str
    @param chunk_size: int
    @param filters: Dict[str, str]
    @return: Tuple[List[Dict], str]
    """
    chunk_list = []
    loop = asyncio.get_event_loop()
    with ThreadPoolExecutor(max_workers=32) as pool:
        for chunk in pd.read_csv(filename, chunksize=chunk_size):
            chunk = await loop.run_in_executor(pool, process_chunk, chunk, filters)
            if not chunk.empty:
                chunk_list.append(chunk.to_dict(orient="records"))
    return chunk_list, filename


def process_chunk(chunk: Any, filters: Dict) -> Any:
    """
    Process Chunk
    @param chunk: dict
    @param filters: dict
    @return: any
    """
    tickers = filters.get("symbol_ids", [])
    date = filters["date"]
    if not tickers:
        chunk = pd.DataFrame(columns=chunk.columns)
    chunk = chunk[chunk["TICKER"].isin(tickers)]
    chunk = chunk[chunk["DATE"] >= date]
    chunk = chunk.apply(replace_empty_values)
    return chunk


def replace_empty_values(col: Any) -> Any:
    """
    Replace empty strings with "" and Number With 0
    @param col: Any
    @return: Any
    """
    if col.dtype == object:
        return col.apply(lambda x: '""' if pd.isna(x) or x == "" else x)
    else:
        return col.fillna(0)


async def update_signal(symbol_id: str, signal: Dict) -> None:
    """
     Update signal.
    :param symbol_id: str
    :param signal: Dict
    :return: None
    """
    async with httpx.AsyncClient() as client:
        try:
            strapi_api_headers = get_strapi_headers()
            update_url = f"{settings.strapi_signals_endpoint}/{symbol_id}"
            response = await client.put(
                url=update_url, headers=strapi_api_headers, json={"data": signal}
            )
            if response.status_code == status.HTTP_200_OK:
                logger.info(f"Updated signal with symbol_id : [{symbol_id}]")
            else:
                logger.error(
                    f"Error in updating signal with symbol_id: [{symbol_id}] - status code [{response.status_code}]"
                )
        except Exception:
            logger.error(
                f"Error during updating signal record for symbol_id : [{symbol_id}] "
            )


async def create_signal(signal: Dict) -> None:
    """
    Create signal.
    :param signal: Dict
    :return: None
    """
    async with httpx.AsyncClient() as client:
        try:
            strapi_api_headers = get_strapi_headers()
            response = await client.post(
                url=f"{settings.strapi_signals_endpoint}",
                headers=strapi_api_headers,
                json={"data": signal},
            )
            if response.status_code == 200 or response.status_code == 201:
                # data = response.json()
                data = response.json().get("data", {})
                if data:
                    attributes = data["attributes"]
                    logger.info(
                        f"Created [{attributes["symbol"]}] signal with txn id - [{attributes["transaction_id"]}]"
                    )
            else:
                logger.error(
                    f"Error in creating signal status code: {response.status_code}"
                )
        except Exception as e:
            logger.error(f"Error during Creating signal record {e}")


async def find_by_symbol_id(ticker: str) -> str | None:
    """
    Gets the ticker details for the ticker symbol passed
    :param ticker:
    :type ticker:
    :return:
    :rtype:
    """
    logger.debug(f"Getting name for ticker - {ticker}")
    name = None
    async with httpx.AsyncClient() as client:
        try:
            api_params = {
                "pagination[limit]": "1",
                "filters[ticker][$eq]": ticker,
                "filters[primary_listing][$eq]": "1",
            }
            strapi_api_headers = get_strapi_headers()
            response = await client.get(
                url=settings.strapi_ticker_detail_endpoint,
                headers=strapi_api_headers,
                params=api_params,
            )
            if response.status_code == status.HTTP_200_OK:
                data = response.json().get("data", [{}])
                if data:
                    attributes = data[0].get("attributes", "")
                    name = attributes["name"]
        except Exception as e:
            logger.error(
                f"Error in getting name for the ticker {ticker} from strapi: {e}"
            )
        # logger.info(f"Name retrieved : {name}")
        return name


async def get_current_tickers_bulk() -> Dict[str, list]:
    """
    Theis function gets all the tickers from the intrinio ticker details collection thru strapi
    :return:
    :rtype:
    """
    logger.info("Get ticker details in bulk..")
    all_tickers: Dict[str, list] = {}
    strapi_url: Union[str, None] = settings.strapi_ticker_detail_bulk_get_endpoint
    api_params = {
        "limit": str(5000),
        "page": str(1),
        "fields[0]": "ticker",
        "fields[1]": "name",
    }
    strapi_api_headers = get_strapi_headers()
    retry_count = 0
    timeout = httpx.Timeout(5.0, connect=5.0)
    async with httpx.AsyncClient(timeout=timeout) as client:
        while strapi_url and retry_count < STRAPI_API_MAX_RETRIES:
            try:
                response = await client.get(
                    url=strapi_url,
                    headers=strapi_api_headers,
                    params=api_params,
                )
                if response.status_code == status.HTTP_200_OK and response.json():
                    data = response.json().get("data", [{}])
                    meta = response.json().get("meta", [{}])
                    if data:
                        for item in data:
                            ticker = item["ticker"]
                            name = item["name"]
                            if ticker in all_tickers:
                                all_tickers[ticker].append(name)
                            else:
                                all_tickers[ticker] = [name]

                        logger.info(
                            f"Total tickers received count: {len(data)} - "
                            f"Overall Tickers count: {len(all_tickers)}"
                        )
                    if meta:
                        pagination = meta.get("pagination", {})
                        if pagination and pagination.get("page") < pagination.get(
                                "pageCount"
                        ):
                            api_params["page"] = pagination["page"] + 1
                        else:
                            strapi_url = None
                    logger.debug(f"Fetched all pages {pagination.get('pageCount')}")
                else:
                    logger.error(
                        f"Error getting ticker details from strapi endpoint status Code: {response.status_code}"
                    )
                    break

            except (httpx.RequestError, httpx.HTTPStatusError) as e:
                logger.error(
                    f"Error in getting ticker details in bulk from strapi: {e}"
                )
                retry_count += 1
                if retry_count >= STRAPI_API_MAX_RETRIES:
                    logger.error(
                        f"Exceeded maximum retry attempts: {STRAPI_API_MAX_RETRIES}"
                    )
                    break
            except Exception as e:
                logger.error(
                    f"Error in getting ticker details in bulk from strapi: {e}"
                )
                break
        logger.info(f"Total tickers retrieved : {len(all_tickers)}")

        return all_tickers


async def get_current_tickers() -> Dict[str, list]:
    """
    Theis function gets all the tickers from the intrinio ticker details collection thru strapi
    :return:
    :rtype:
    """
    logger.info("Getting current tickers in strapi")
    all_tickers: Dict[str, list] = {}
    strapi_url: Union[str, None] = settings.strapi_ticker_detail_endpoint
    api_params = {
        "pagination[pageSize]": str(1000),
        "pagination[page]": str(1),
        "fields[0]": "ticker",
        "fields[1]": "name",
    }
    strapi_api_headers = get_strapi_headers()
    retry_count = 0
    timeout = httpx.Timeout(5.0, connect=5.0)

    async with httpx.AsyncClient(timeout=timeout) as client:
        while strapi_url and retry_count < STRAPI_API_MAX_RETRIES:
            try:
                response = await client.get(
                    url=strapi_url,
                    headers=strapi_api_headers,
                    params=api_params,
                )
                if response.status_code == status.HTTP_200_OK and response.json():
                    data = response.json().get("data", [{}])
                    meta = response.json().get("meta", [{}])
                    if data:
                        for item in data:
                            ticker = item["attributes"]["ticker"]
                            name = item["attributes"]["name"]
                            if ticker in all_tickers:
                                # Append name to existing list
                                all_tickers[ticker].append(name)
                            else:
                                # Create a new list with the name
                                all_tickers[ticker] = [name]

                        logger.info(
                            f"Total tickers received count: {len(data)} - "
                            f"Overall Tickers count: {len(all_tickers)}"
                        )
                    if meta:
                        pagination = meta.get("pagination", {})
                        if pagination and pagination.get("page") < pagination.get(
                            "pageCount"
                        ):
                            api_params["pagination[page]"] = pagination["page"] + 1
                        else:
                            strapi_url = None
                    logger.debug(f"Fetched all pages {pagination.get('pageCount')}")
                else:
                    logger.error(
                        f"Error getting signals from strapi endpoint status Code: {response.status_code}"
                    )
                    break
            except (httpx.RequestError, httpx.HTTPStatusError) as e:
                logger.error(
                    f"Error in Getting current tickers in strapi from strapi: {e}"
                )
                retry_count += 1
                if retry_count >= STRAPI_API_MAX_RETRIES:
                    logger.error(
                        f"Exceeded maximum retry attempts: {STRAPI_API_MAX_RETRIES}"
                    )
                    break
            except Exception as e:
                logger.error(
                    f"Error in Getting current tickers in strapi from strapi: {e}"
                )
                break

        logger.info(f"Total tickers retrieved : {len(all_tickers)}")
        return all_tickers


async def find_ticker_price_by_symbol(symbol: str) -> Any:
    """
    From Strapi ticker price collection, gets the ticker price for given symbol
    :param symbol:
    :type symbol:
    :return:
    :rtype:
    """
    logger.info(f"Getting ticker price for symbol - [{symbol}]")
    data = []
    async with httpx.AsyncClient() as client:
        try:
            api_params = {
                "sort": "DATE:desc",
                "pagination[limit]": "1",
                "filters[TICKER][$eq]": symbol,
            }
            strapi_api_headers = get_strapi_headers()
            response = await client.get(
                url=settings.strapi_ticker_price_endpoint,
                headers=strapi_api_headers,
                params=api_params,
            )
            if response.status_code == status.HTTP_200_OK:
                data = response.json().get("data", [])
                if not data:
                    logger.info(
                        f"Signals list is coming empty status code: {response.status_code}"
                    )
            else:
                logger.info(
                    f"Error in getting ticker price for symbol in strapi endpoint status Code: {response.status_code}"
                )
        except Exception as e:
            logger.error(f"Error in getting ticker price for symbol from strapi: {e}")
        return data


async def update_signal_in_db(symbol_id: str, signal: Dict) -> None:
    """
     Update signals in the signals strapi collections
    :param symbol_id: str
    :param signal: Dict
    :return: None
    """
    async with httpx.AsyncClient() as client:
        try:
            strapi_api_headers = get_strapi_headers()
            update_url = f"{settings.strapi_signals_endpoint}/{symbol_id}"
            response = await client.put(
                url=update_url, headers=strapi_api_headers, json={"data": signal}
            )
            if response.status_code == status.HTTP_200_OK:
                logger.info(f"Updated signal with symbol_id: [{symbol_id}]")
            else:
                logger.error(
                    f"Error in updating signal with symbol_id: [{symbol_id}] - status code [{response.status_code}]"
                )
        except Exception as ex:
            logger.error(
                f"Error - [{ex}] during updating signal record for symbol_id : [{symbol_id}]"
            )
