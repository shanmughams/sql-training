from datetime import datetime
from typing import Dict, List

import httpx
from starlette import status

from core.config import settings
from core.logger import logger
from utils.constants import (
    TRADESMITH_RSI_AUTHENTICATE_ENDPOINT,
    TRADESMITH_RSI_SIGNALS_ENDPOINT,
    TRADESMITH_RSI_SIGNALS_WITH_DATE_ENDPOINT,
)


async def get_tradesmith_access_token() -> str:
    """
    Get TradesSmith API token
    @return: TradesSmith Access token
    """
    token = ""
    async with httpx.AsyncClient() as client:
        try:
            logger.info("RSI API Authentication starting.....")
            response = await client.post(
                url=TRADESMITH_RSI_AUTHENTICATE_ENDPOINT,
                json={
                    "Username": settings.tradesmith_username,
                    "Password": settings.tradesmith_password,
                },
            )
            if response.status_code == status.HTTP_200_OK:
                token = response.json().get("AccessToken", "")
                if token:
                    logger.info("RSI API Authentication completed")
                else:
                    logger.error(
                        "RSI API Authentication Completed But Token Was Not Present!!"
                    )
            else:
                logger.error(
                    f"Error Getting Access Token Status Code: {response.status_code}"
                )
        except Exception as e:
            logger.error(f"Error during RSI API Authentication: {e}")
        return token


async def get_rsi_signals(access_token: str, update_date: str | None) -> List[Dict]:
    """
    Get Rsi signals from TradesSmith Api
    :param access_token: str
    :param update_date: str
    :return: Dict
    """
    data: List[Dict] = []
    logger.debug(f"Getting RSI signals from TradesSmith Api - {datetime.now()}")
    async with httpx.AsyncClient() as client:
        try:
            headers = {
                "Content-Type": "application/json",
                "Authorization": f"Bearer {access_token}",
            }
            if update_date:
                tradesmith_url = TRADESMITH_RSI_SIGNALS_WITH_DATE_ENDPOINT.format(
                    update_date=update_date
                )
            else:
                tradesmith_url = TRADESMITH_RSI_SIGNALS_ENDPOINT
            logger.info(
                f"Trademisth API URL set for getting signal collection- {tradesmith_url}"
            )
            response = await client.get(
                url=tradesmith_url,
                headers=headers,
            )
            if response.status_code == status.HTTP_200_OK:
                data = response.json()
            else:
                logger.error(
                    f" Error getting rsi signals from tradesmith api with status code: {response.status_code}"
                )
        except Exception as e:
            logger.error(f"Error during on Fetching RSI signals: {e}")

        logger.debug(f"RSI signals from TradesSmith Api end - {datetime.now()}")
        return data
