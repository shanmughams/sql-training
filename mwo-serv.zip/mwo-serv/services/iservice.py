from abc import ABC, abstractmethod
from typing import Any, Generic, Sequence, TypeVar

T = TypeVar("T")


class IGenericService(ABC, Generic[T]):
    @abstractmethod
    async def get_all(self, skip: int, limit: int) -> Sequence[Any]:
        pass

    @abstractmethod
    async def get_by_id(self, item_id: int) -> Any | None:
        pass

    @abstractmethod
    async def create(self, item: T) -> T:
        pass

    @abstractmethod
    async def update(self, item_id: int, item_data: dict) -> T | None:
        pass

    @abstractmethod
    async def delete(self, item_id: int) -> None:
        pass
