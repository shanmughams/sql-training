import json
import time
from datetime import datetime
from typing import Any, Dict, Generator, List

import numpy as np

from core.logger import logger
from services.intrinio_service import (
    fetch_all_ticker_details_from_intrinio,
    fetch_ticker_details_for_symbol_code,
    get_ticker_prices_from_intrinio,
)
from services.strapi_service import (
    bulk_insert_unique_ticker_details,
    create_signal,
    find_by_symbol_id,
    find_signal_by_transaction_id,
    find_signals_by_symbol_buy_date,
    find_ticker_price_by_symbol,
    find_ticker_price_on_days_sorted,
    find_ticker_prices_on_9_months,
    get_all_open_buys_signals,
    get_all_recent_sell_signals,
    get_current_tickers_bulk,
    get_last_update_date_from_signals,
    get_rsi_signals_on_buy_threshold_bulk,
    reset_current_previous_buy_signals,
    update_signal,
    update_signal_in_db,
)
from services.tradesmith_rsi_service import get_rsi_signals, get_tradesmith_access_token
from utils.constants import (
    ETF_MARKET_INDICES_DATE_FORMAT,
    MARKET_CAP_LIMIT,
    SPY_ETF_SYMBOL,
    SYMBOL_CODES,
)
from utils.rsi_signal_cron_summary_report import cron_report
from utils.rsi_signals_util import (
    filter_signals_on_buys_without_sells,
    get_min_score,
    get_unique_tickers,
    is_average_within_price_range,
    map_security_field,
    parse_signal_data,
    prepare_signal_body,
    transform_ticker_name,
)
from utils.util import convert_string_to_datetime_obj, is_empty


async def save_signals(signals: List[Dict]) -> None:
    """
    Save signals into Strapi Collection
    @param signals: List
    @return: None
    """
    for signal in signals:
        market_cap = signal.get("MarketCap", None)
        if market_cap and market_cap >= MARKET_CAP_LIMIT:
            cron_report.incr_rsi_signals_over_500m_cap_count()
            txn_id = signal.get("TransactionId", None)
            if txn_id:
                signal_by_txn = await find_signal_by_transaction_id(txn_id)
                if signal_by_txn:
                    attributes = signal_by_txn["attributes"]
                    symbol_id = signal_by_txn["id"]
                    attributes["update_date"] = signal.get("UpdateDate")
                    sell_date = signal.get("SellDate", None)
                    if sell_date:
                        attributes["update_date"] = signal.get("UpdateDate")
                        attributes["entry_rsi_sell_date"] = signal.get(
                            "EntryRsiSellDate"
                        )
                        attributes["sell_rsi"] = signal.get("SellRsi")
                        attributes["old_sell_date"] = signal.get("SellDate")
                        attributes["old_sell_price"] = signal.get("SellPrice")
                    await update_signal(symbol_id, attributes)
                    cron_report.incr_existing_rsi_signals_updated_from_api_count()
                else:
                    signal_by_id_buy_date_threshold = (
                        await find_signals_by_symbol_buy_date(signal)
                    )
                    if signal_by_id_buy_date_threshold:
                        attributes = signal_by_id_buy_date_threshold["attributes"]
                        symbol_id = signal_by_id_buy_date_threshold["id"]
                        if attributes["count"] is None:
                            attributes["count"] = 1
                        else:
                            attributes["count"] += 1
                        await update_signal(symbol_id, attributes)
                        cron_report.incr_existing_rsi_signals_updated_from_api_count()
                    else:
                        logger.debug(
                            f"Creating new signal in strapi : [{signal['SymbolId']}]"
                        )
                        signal = prepare_signal_body(signal)
                        await create_signal(signal)
                        cron_report.incr_new_rsi_signals_from_api_count()
            else:
                logger.info(f"No txn_id: [{txn_id}] in signal")


async def get_signals() -> None:
    """
    Get Signals
    :return: None
    """
    last_update_date_str = None
    last_update_date = await get_last_update_date_from_signals()
    if last_update_date:
        last_update_date_str = convert_string_to_datetime_obj(
            last_update_date,
            "%Y-%m-%dT%H:%M:%S.%fZ",
            ETF_MARKET_INDICES_DATE_FORMAT,
        )
        cron_report.rsi_signals_last_update_date_used = last_update_date_str
    else:
        cron_report.rsi_signals_last_update_date_used = ""
        logger.info(
            "No last_update_date from DB. Getting all symbols without last update date"
        )

    access_token = await get_tradesmith_access_token()
    if access_token:
        logger.info("Authentication successful with Tradesmith")
        rsi_signals = await get_rsi_signals(access_token, last_update_date_str)
        if rsi_signals and len(rsi_signals) > 0:
            logger.info(
                f"Total RSI Received - [{len(rsi_signals)}], "
                f"for the update date - [{last_update_date_str}] "
            )
            cron_report.total_rsi_signals_from_api = len(rsi_signals)
            await save_signals(rsi_signals)
        else:
            logger.warn(
                f"No RSI signals available for - {last_update_date_str} in Tradesmith API"
            )
    else:
        logger.error("Failed to get Tradesmith RSI API Access Token")


def chunk_list(lst: List[Any], chunk_size: int) -> Generator[List[Any], None, None]:
    """Helper function to split a list into chunks of specified size."""
    for i in range(0, len(lst), chunk_size):
        yield lst[i: i + chunk_size]


async def get_ticker_details_from_intrinio_on_symbols(ticker_symbols: List) -> int:
    """

    :param ticker_symbols:
    :type ticker_symbols:
    :return:
    :rtype:
    """
    final_count = 0
    all_tickers_data = await fetch_all_ticker_details_from_intrinio(ticker_symbols)
    if all_tickers_data is None or len(all_tickers_data) == 0:
        logger.info("No Ticker details fetched from intrinio")
        return final_count
    existing_tickers: Dict[str, list] = await get_current_tickers_bulk()
    start_time = time.time()
    if existing_tickers is None or len(existing_tickers) == 0:
        logger.info("There is no tickers details already existing in DB")
        cron_report.existing_ticker_details_count = 0
    else:
        cron_report.existing_ticker_details_count = len(existing_tickers)
        logger.info(
            f"There are [{len(existing_tickers)}] tickers details already existing in DB"
        )
    mappped_tickers_data = map_security_field(all_tickers_data)
    unique_tickers_data = get_unique_tickers(mappped_tickers_data, existing_tickers)
    final_count = await bulk_insert_unique_ticker_details(unique_tickers_data)
    end_time = time.time()
    cron_report.ticker_details_download_time_taken = end_time - start_time
    return final_count


async def get_ticker_details_from_intrinio_on_symbol_codes() -> None:
    """
    Gets the latest ticker details from initrinio APIs fpr the symbol codes ['DR', 'ETN', 'ETF', 'EQS'],
    and saves in the DB if it's not already saved checks - On getAllSymbols
    :return:
    :rtype:
    """
    # existing_tickers: Dict[str, list] = await get_current_tickers()
    existing_tickers: Dict[str, list] = await get_current_tickers_bulk()
    if existing_tickers:
        cron_report.existing_ticker_details_count = len(existing_tickers)
        logger.info(
            f"There are [{len(existing_tickers)}] tickers details already existing in DB"
        )
    else:
        logger.info("There is no tickers details already existing in DB")
        cron_report.existing_ticker_details_count = 0
    total_time_taken: float = 0
    for code in SYMBOL_CODES:
        total_time_taken_for_code = await fetch_ticker_details_for_symbol_code(
            code, existing_tickers
        )
        total_time_taken += total_time_taken_for_code
    logger.info(
        f"Total time taken to load All Ticker details - {SYMBOL_CODES}: {total_time_taken:.2f} seconds"
    )
    cron_report.ticker_details_download_time_taken = total_time_taken


async def update_symbol_stop_loss_sell_prices(
        signal: Dict, spy_etf_2_days_price_list: List
) -> bool:
    """
    Updates symbol stop loss and sell prices
    :param signal:
    :type signal:
    :return:
    :rtype:
    """
    symbol = signal["symbol"]
    symbol_updated = False
    if not is_average_within_price_range(signal):
        return symbol_updated

    ticker_info_details = await find_ticker_price_by_symbol(symbol)
    if ticker_info_details is None or len(ticker_info_details) == 0:
        return symbol_updated

    ticker_info = ticker_info_details[0].get("attributes")
    if ticker_info is None:
        return symbol_updated

    if spy_etf_2_days_price_list and len(spy_etf_2_days_price_list) >= 2:
        logger.info(
            f"SPY Ticker Price on Last 2 days - Adj close [0] : {spy_etf_2_days_price_list[0]["ADJ_CLOSE"]}, "
            f"Adj close [1] : {spy_etf_2_days_price_list[1]["ADJ_CLOSE"]}"
        )
        stop_loss = ((ticker_info["ADJ_CLOSE"] / signal["buy_price"]) - 1) - (
                (
                        spy_etf_2_days_price_list[0]["ADJ_CLOSE"]
                        / spy_etf_2_days_price_list[1]["ADJ_CLOSE"]
                )
                - 1
        )
        if ticker_info["CLOSE"] >= signal["sell_goal"] or stop_loss <= -0.2:
            signal_date = ticker_info["DATE"]
            # logger.info(f"signal_date - [{signal_date}]  - type - [{type(signal_date)}")
            signal["sell_price"] = ticker_info["ADJ_CLOSE"]
            signal["sell_date"] = signal_date
            signal["sell_date_formatted"] = datetime.strptime(
                signal_date, "%Y-%m-%d"
            ).strftime("%m-%d-%Y")
            signal["stop_loss"] = stop_loss <= -0.2
            signal["update_date"] = signal_date

    signal["yesterday_close"] = ticker_info["ADJ_CLOSE"]
    signal["percent_return"] = (
                                       (ticker_info["ADJ_CLOSE"] - signal["buy_price"]) / signal["buy_price"]
                               ) * 100
    symbol_updated = True
    return symbol_updated


async def update_symbol_sell_goal_min_max_prices(
        signal: Dict, ticker_high: List[Dict]
) -> None:
    """
    updates signal's stdev, min_price, max_price
    :param signal:
    :type signal:
    :param ticker_high:
    :type ticker_high:
    :return:
    :rtype:
    """
    last_thirty_days = ticker_high[:30]
    thirty_close_attributes = [ticker["attributes"] for ticker in last_thirty_days]
    thirty_close = [ticker["ADJ_CLOSE"] for ticker in thirty_close_attributes]
    thirty_day_avg = np.mean(thirty_close)
    signal["average"] = thirty_day_avg
    last_forty_five_days = ticker_high[:45]
    last_forty_five_attributes = [
        ticker["attributes"] for ticker in last_forty_five_days
    ]
    ticker = max(last_forty_five_attributes, key=lambda x: x["ADJ_HIGH"])
    signal["sell_goal"] = ((ticker["ADJ_HIGH"] - signal["buy_price"]) * 0.66) + signal[
        "buy_price"
    ]
    signal["trailing_high"] = ticker["ADJ_HIGH"]
    all_highs_attributes = [ticker["attributes"] for ticker in ticker_high]
    all_highs = [ticker["ADJ_HIGH"] for ticker in all_highs_attributes]
    average = np.mean(all_highs)
    st_dev = np.std(all_highs)
    signal["stdev"] = st_dev
    signal["min_price"] = average - st_dev
    signal["max_price"] = average + st_dev
    logger.info(
        f"Set Sell goal, trailing_high, avg, min & max price set for [{signal["symbol"]}], "
        f"txn id - [{signal["transaction_id"]}]"
    )


async def handle_symbol_sell_goal_min_max_prices(signal: Dict) -> bool:
    """
    Sets the sell goal, min max average prices for the signals
    :param signal:
    :type signal:
    :return:
    :rtype:
    """
    # buy_date = signal["buy_date"]
    buy_date = signal["buy_date_formatted"]
    symbol = signal["symbol"]
    logger.debug(
        f"Handle symbol [{symbol}] - buy date - [{buy_date}] for sell_goal_min_max_prices"
    )
    ticker_high = await find_ticker_prices_on_9_months(symbol, buy_date)
    sell_goal_updated = False
    if ticker_high and len(ticker_high) > 0:
        await update_symbol_sell_goal_min_max_prices(signal, ticker_high)
        sell_goal_updated = True

    return sell_goal_updated


async def sanitize_symbol_name(signal: Dict) -> bool:
    """
    Updates the Symbol name by removing some details.
    :param signal:
    :type signal:
    :return: True when name got updated
    :rtype:
    """
    symbol_updated = False
    symbol = signal["symbol"]
    if symbol:
        ticker_name = await find_by_symbol_id(symbol)
        if ticker_name:
            original_name = ticker_name
            sanitized_name = transform_ticker_name(original_name)
            if original_name == sanitized_name:
                symbol_updated = False
            else:
                signal["symbol_name"] = sanitized_name
                symbol_updated = True
    return symbol_updated


async def get_signal_returns(parsed_signals: List[Dict]) -> None:
    """
    update symbol sell goal and stop loss, min max prices
    :param parsed_signals:
    :type parsed_signals:
    :return:
    :rtype:
    """
    # for signal_txn in parsed_signals:
    spy_etf_ticker_price_details_2_days = await find_ticker_price_on_days_sorted(
        SPY_ETF_SYMBOL, 2
    )
    spy_etf_ticker_price_details = [
        ticker["attributes"] for ticker in spy_etf_ticker_price_details_2_days
    ]
    for signal in parsed_signals:
        symbol_updated = False
        symbol_id = signal["id"]
        # signal = signal["attributes"]
        symbol = signal["symbol"]
        logger.info(
            f"Handling for signal in signal returns for [{symbol}], txn id - [{signal['transaction_id']}]"
        )
        if not signal["sell_date"]:
            if not signal["sell_goal"]:
                symbol_updated = await sanitize_symbol_name(signal)
                sell_goal_updated = await handle_symbol_sell_goal_min_max_prices(signal)
                if sell_goal_updated:
                    cron_report.add_rsi_signals_sell_goal_handled(symbol)

                symbol_updated = sell_goal_updated or symbol_updated

            stop_loss_updated = await update_symbol_stop_loss_sell_prices(
                signal, spy_etf_ticker_price_details
            )
            if stop_loss_updated:
                cron_report.add_rsi_signals_stop_loss_handled(symbol)

            symbol_updated = stop_loss_updated or symbol_updated

            if symbol_updated:
                await update_signal_in_db(symbol_id, signal)
        logger.info(
            f"Signal handled in signal returns for signal - [{symbol}], txn id - [{signal['transaction_id']}]"
        )


async def set_sells_triggers_in_signals(rsi_signals_list: List) -> None:
    for rsi_signal_data in rsi_signals_list:
        rsi_signal = rsi_signal_data["attributes"]
        if rsi_signal:
            rsi_signal["sell_signal"] = True
            logger.info(f"Set Sell trigger for signal - [{rsi_signal}]")


async def set_buys_triggers_in_signals(rsi_signals_list: List) -> None:
    for rsi_signal_data in rsi_signals_list:
        rsi_signal = rsi_signal_data["attributes"]
        if rsi_signal:
            rsi_signal["buy_signal"] = True
            logger.info(f"Set buy trigger for signal - [{rsi_signal}]")


async def update_parsed_signals(rsi_signals_list: List) -> None:
    for rsi_signal_data in rsi_signals_list:
        rsi_signal = rsi_signal_data["attributes"]
        rsi_symbol_id = rsi_signal_data["id"]
        await update_signal(rsi_symbol_id, rsi_signal)


async def get_recent_sells_buys() -> Dict:
    await reset_current_previous_buy_signals()
    filtered_sell_signals = []
    filtered_buys_no_sell_signals = []
    recent_sell_signals = await get_all_recent_sell_signals()
    if recent_sell_signals and len(recent_sell_signals) > 0:
        filtered_sell_signals = await parse_signal_data(recent_sell_signals)
        if filtered_sell_signals and len(filtered_sell_signals):
            await set_sells_triggers_in_signals(filtered_sell_signals)
            await update_parsed_signals(filtered_sell_signals)
            cron_report.add_sell_signals_from_list(filtered_sell_signals)

    result_buy_signals = await get_all_open_buys_signals()
    if result_buy_signals and len(result_buy_signals) > 0:
        result_buys_no_sell_signals = filter_signals_on_buys_without_sells(
            recent_sell_signals, result_buy_signals
        )
        if result_buys_no_sell_signals and len(result_buys_no_sell_signals) > 0:
            filtered_buys_no_sell_signals = await parse_signal_data(
                result_buys_no_sell_signals
            )
            if filtered_buys_no_sell_signals and len(filtered_buys_no_sell_signals):
                await set_buys_triggers_in_signals(filtered_buys_no_sell_signals)
                await update_parsed_signals(filtered_buys_no_sell_signals)
                cron_report.add_buy_signals_from_list(filtered_buys_no_sell_signals)

    short_term_ideas = {
        "sell_signals": filtered_sell_signals,
        "buy_signals": filtered_buys_no_sell_signals,
    }
    return short_term_ideas


async def set_current_previous_buy_signals() -> None:
    """
    clears the  current and previous buy signals and sets the new one
    :return:
    :rtype:
    """
    await reset_current_previous_buy_signals()


def create_cron_job_response(
        status: str, message: str, data: Dict[str, list[str]]
) -> Dict[str, str]:
    response = {"status": status, "message": message}
    if data:
        response["data"] = json.dumps(data)
    return response


def end_cron_job() -> Dict:
    """

    :return:
    :rtype:
    """
    logger.info(f"Signal Cron Ended on {datetime.now()}")
    cron_report.set_cron_end_time_formatted()
    cron_report.log_cron_summary_report()
    return create_cron_job_response(
        "success",
        "Signal cron job completed successfully",
        {
            "sell_signals": cron_report.sell_signals,
            "buy_signals": cron_report.buy_signals,
        },
    )


async def signals_cron() -> dict[str, str]:
    """
    Signals Cron Job
    @return: str
    """
    logger.info(f"Signal Cron Started on {datetime.now()}")
    cron_report.set_cron_start_time_formatted()
    total_signals_with_min_score = 0
    min_score_signals = []
    no_resp_data: dict[str, list[str]] = {}
    try:
        await get_signals()
        signals_from_strapi = await get_rsi_signals_on_buy_threshold_bulk()
        if is_empty(signals_from_strapi):
            logger.info("No Signals retrieved on buy threshold to work further")
            return end_cron_job()

        filtered_signal_ids = []
        symbol_ids_to_get_price = set()
        parsed_signals = []
        cron_report.total_rsi_signals_on_buy_threshold = len(signals_from_strapi)
        for buy_rsi_signal in signals_from_strapi:
            # signal = buy_rsi_signal["attributes"]
            signal = buy_rsi_signal
            min_score = await get_min_score(signal)
            symbol = signal["symbol"]
            if min_score >= 4:
                total_signals_with_min_score += 1
                min_score_signals.append(symbol)
                symbol_ids_to_get_price.add(symbol)
                parsed_signals.append(buy_rsi_signal)
                filtered_signal_ids.append(symbol)
                cron_report.add_signals_with_min_score_required(symbol)
                cron_report.incr_rsi_signals_with_min_score_on_4_count()
        logger.info(
            f"Min score signals count >= 4 :  [{total_signals_with_min_score}], "
            f" min_score_signals symbols : {min_score_signals}"
        )
        logger.info(f"filtered_signal_ids - {filtered_signal_ids}")

        symbol_ids_to_get_price.add(SPY_ETF_SYMBOL)
        try:
            await get_ticker_prices_from_intrinio(symbol_ids_to_get_price)
        except Exception as ex:
            logger.error(
                f"Error during Getting Ticker Prices: {str(ex)}", exc_info=True
            )
            return create_cron_job_response(
                "failure",
                f"Error during Getting Ticker Prices: {str(ex)}",
                no_resp_data,
            )
        try:
            tickets_inserted = await get_ticker_details_from_intrinio_on_symbols(
                list(symbol_ids_to_get_price)
            )
            if tickets_inserted > 0:
                cron_report.new_ticker_details = tickets_inserted
        except Exception as ex:
            logger.error(
                f"Error during Getting Ticker details: {str(ex)}", exc_info=True
            )
            return create_cron_job_response(
                "failure",
                f"Error during Getting Ticker details: {str(ex)}",
                no_resp_data,
            )
        try:
            await get_signal_returns(parsed_signals)
        except Exception as ex:
            logger.error(
                f"Error during Getting Signal returns: {str(ex)}", exc_info=True
            )
            return create_cron_job_response(
                "failure",
                f"Error during Getting Signal returns: {str(ex)}",
                no_resp_data,
            )
        try:
            await get_recent_sells_buys()
        except Exception as ex:
            logger.error(f"Error during recent sells buys: {str(ex)}", exc_info=True)
            return create_cron_job_response(
                "failure", f"Error during recent sells buys: {str(ex)}", no_resp_data
            )
        # try:
        #     await set_current_previous_buy_signals()
        # except Exception as ex:
        #     logger.error(
        #         f"Error during setting current and previous buy signals: {str(ex)}",
        #         exc_info=True,
        #     )
        #     return create_cron_job_response(
        #         "failure",
        #         f"Error during setting current and previous buy signals: {str(ex)}",
        #         no_resp_data,
        #     )

    except Exception as ex:
        logger.error(f"Error during Getting RSI signals: {ex}")
        return create_cron_job_response(
            "failure", f"Error during Getting RSI signals: {ex}", no_resp_data
        )

    return end_cron_job()
