import json
import os
from typing import Any, Dict, List

import httpx
from fastapi import APIRouter
from starlette import status

from core.config import settings
from core.logger import logger
from schemas.market_index_schema import (
    EtfMarketTicker,
    InternalServerError,
    MarketIndexResponseSchema,
    MarketIndexSchema,
    Unauthorized,
)
from utils.constants import (
    ETF_MARKET_INDICES_CREATE_UPDATE_DATE_TIME_FORMAT,
    ETF_MARKET_INDICES_DATE_FORMAT,
    INTRINIO_ETF_PRICE_ENDPOINT,
    INTRINIO_ETF_REALTIME_PRICE_ENDPOINT,
)
from utils.util import get_utc_time_str

market_index_router = APIRouter()


async def etf_market_indices(tickers: list) -> List[str]:
    """
    Etf Market Indices
    @tickers: List of tickers
    return: List[str]
    """
    result = []
    try:
        for ticker in tickers:
            entry_dict = await get_market_indices_from_intrinio(ticker=ticker)
            # Check If ticker entry Exists
            exists, ticker_data = await is_ticker_entry_exists(ticker)
            if not exists:
                # Creating New Market Index Entry
                logger.info(f"Creating New Market Index Entry {ticker}")
                data = await create_etf_market_index_entry(entry_dict)
            else:
                # Updating Market Index Entry
                logger.info(f"Updating Market Index Entry For {ticker}")
                data = await updating_etf_market_index_entry(
                    entry_dict=entry_dict, ticker_data=ticker_data
                )
            result.append(data)
    except Exception as e:
        data = InternalServerError(data=f"{e}").json()
        result.append(data)
        logger.error(data)
    return result


async def is_ticker_entry_exists(ticker: str) -> tuple[bool, dict]:
    """
    is_ticker_entry_exists
    @ticker: str
    return: tuple[bool, dict]
    """
    async with httpx.AsyncClient() as client:
        strapi_etf_market_entry = await client.get(
            url=settings.strapi_etf_market_indices_endpoint,
            headers={
                "content-type": "application/json",
                "Authorization": f"Bearer {os.environ['STRAPI_TOKEN']}",
            },
            params={
                "filters[etf_symbol]": ticker,
            },
        )
        strapi_etf_market_entry_data = strapi_etf_market_entry.json()
        data = strapi_etf_market_entry_data.get("data", [])
        meta = strapi_etf_market_entry_data.get("meta", {})
        status_code = strapi_etf_market_entry.status_code
        if status_code == status.HTTP_200_OK and data and meta:
            return True, EtfMarketTicker(**strapi_etf_market_entry_data).dict()
        else:
            logger.error(
                f"Data: {data}, Meta: {meta}, ticker: {ticker}, status: {strapi_etf_market_entry.status_code}"
            )
            return False, dict()


async def get_market_indices_from_intrinio(ticker: str) -> dict:
    """
    get_market_indices_from_intrinio
    @ticker: str
    return: str
    """
    async with httpx.AsyncClient() as client:
        last_price_dict: Dict = dict()
        volume_change_percent_dict: Dict = dict()
        volume_change_percent_dict["etf_symbol"] = ticker
        # yesterday date always 3 days back
        # because the market will be closed on weekends for 2 days
        yesterday_date: str = get_utc_time_str(
            date_time_format=ETF_MARKET_INDICES_DATE_FORMAT, past_time=True, days_ago=3
        )
        today_date: str = get_utc_time_str(
            date_time_format=ETF_MARKET_INDICES_DATE_FORMAT
        )
        # Getting security & stock Prices & ETF Name
        volume_change_percent_res = await client.get(
            url=INTRINIO_ETF_PRICE_ENDPOINT.format(ticker=ticker),
            params={
                "api_key": settings.intrinio_api_key,
                "start_date": yesterday_date,
                "end_date": today_date,
            },
        )
        volume_change_percent_data: Dict[str, Any] = volume_change_percent_res.json()
        if volume_change_percent_res.status_code == status.HTTP_200_OK:
            if volume_change_percent_data.get(
                "security", {}
            ) and volume_change_percent_data.get("stock_prices", []):
                volume_change_percent_dict["etf_name"] = volume_change_percent_data[
                    "security"
                ].get("name", "")
                volume_change_percent_dict["market_date_from"] = yesterday_date
                volume_change_percent_dict["market_date_to"] = today_date
                stock_prices = volume_change_percent_data["stock_prices"]
                stock_price = stock_prices[0]
                volume_change_percent_dict["change"] = stock_price.get(
                    "change", float(0)
                )
                volume_change_percent_dict["change_percent"] = stock_price.get(
                    "percent_change", float(0)
                )
                volume_change_percent_dict["volume"] = stock_price.get(
                    "volume", float(0)
                )
                logger.info(
                    msg="Got volume, change, change_percent From Intrinio Prices Api"
                )
        else:
            if volume_change_percent_res.status_code == status.HTTP_401_UNAUTHORIZED:
                logger.error(
                    Unauthorized(
                        human=volume_change_percent_data["human"],
                        data=volume_change_percent_data["message"],
                    ).json()
                )
            else:
                logger.error(
                    InternalServerError(
                        data=volume_change_percent_data["message"],
                    ).json()
                )
        #  Getting Last Price
        realtime_price_res = await client.get(
            url=INTRINIO_ETF_REALTIME_PRICE_ENDPOINT.format(ticker=ticker),
            params={
                "api_key": settings.intrinio_api_key,
            },
        )
        realtime_price_data = realtime_price_res.json()
        if realtime_price_res.status_code == status.HTTP_200_OK:
            if realtime_price_data.get("last_price", float(0)):
                last_price_dict["price"] = realtime_price_data.get(
                    "last_price", float(0)
                )
                logger.info(msg="Got Last Price From Intrinio Realtime Prices Api")
        else:
            if realtime_price_res.status_code == status.HTTP_401_UNAUTHORIZED:
                logger.error(
                    Unauthorized(
                        human=realtime_price_data["human"],
                        data=realtime_price_data["message"],
                    ).json()
                )
            else:
                logger.error(
                    InternalServerError(
                        data=volume_change_percent_data["message"],
                    ).json()
                )
    return {**volume_change_percent_dict, **last_price_dict}


def calculate_final_chart_data(older_chart_data: list, new_chart_data: list) -> list:
    """
    calculate_final_chart_data
    @older_chart_data: list
    @new_chart_data: list
    return: list
    """
    # Chart Data window size is always 36
    # Market Open time 9 AM closing 6 --> 9*60 mins /15 mins = 36
    #  If len of older_chart_data is in between 0 and 36
    #  (0 and 35 are included)
    if 0 <= len(older_chart_data) <= 35:
        older_chart_data.extend(new_chart_data)
        return older_chart_data
    else:
        #  If len of older_chart_data is greater than 36
        del older_chart_data[0]
        older_chart_data.extend(new_chart_data)
        return older_chart_data


async def updating_etf_market_index_entry(
    entry_dict: Dict,
    ticker_data: Dict,
) -> str:
    """
    updating_etf_market_index_entry
    @entry_dict: dict
    @ticker_data: dict
    Return: str
    """
    async with httpx.AsyncClient() as client:
        # updating Data into Strapi Collection
        data = ticker_data.get("data", [{}])[0]
        if not data:
            logger.error("Ticker Data is Coming Null, Skipping Update!!")
            return json.dumps(
                {"error": f"Skipping Update because Ticker Data {ticker_data}"}
            )
        else:
            logger.info("Updating Content in Strapi ETF Market Index")
            symbol_id = data["id"]
            attributes = data["attributes"]
            older_chart_data: List = attributes.get("chart_data", [])
            updated_at = get_utc_time_str(
                date_time_format=ETF_MARKET_INDICES_CREATE_UPDATE_DATE_TIME_FORMAT,
                extra_formatting=3,
            )
            new_chart_data: List = [
                {"updated_at": updated_at, "price": entry_dict["price"]}
            ]
            if older_chart_data:
                final_chart_data = calculate_final_chart_data(
                    older_chart_data=older_chart_data, new_chart_data=new_chart_data
                )
                entry_dict["chart_data"] = final_chart_data
            else:
                entry_dict["chart_data"] = new_chart_data
            strapi_etf_market_indices = await client.put(
                url=f"{settings.strapi_etf_market_indices_endpoint}/{symbol_id}",
                json=json.loads(
                    MarketIndexResponseSchema(
                        data=MarketIndexSchema(**entry_dict)
                    ).json()
                ),
                headers={
                    "Content-Type": "application/json",
                    "Authorization": f"Bearer {os.environ['STRAPI_TOKEN']}",
                },
            )
            strapi_etf_market_data = json.loads(strapi_etf_market_indices.content)
            if strapi_etf_market_indices.status_code == status.HTTP_200_OK:
                data = json.dumps(entry_dict)
                logger.info(f"Updated Market Index Entry For Symbol Id {symbol_id}")
            else:
                message = strapi_etf_market_data["error"]["message"]
                data = InternalServerError(data=message).json()
                logger.error(
                    f"Failed to Update Market Index Entry For Symbol Id {symbol_id}"
                )
            return data


async def create_etf_market_index_entry(entry_dict: Dict) -> str:
    async with httpx.AsyncClient() as client:
        updated_at = get_utc_time_str(
            date_time_format=ETF_MARKET_INDICES_CREATE_UPDATE_DATE_TIME_FORMAT,
            extra_formatting=3,
        )
        logger.info("Adding Chart Data For New Entry")
        entry_dict["chart_data"] = [
            {"updatedAt": updated_at, "price": entry_dict["price"]}
        ]
        strapi_etf_market_indices = await client.post(
            url=settings.strapi_etf_market_indices_endpoint,
            json=json.loads(
                MarketIndexResponseSchema(data=MarketIndexSchema(**entry_dict)).json()
            ),
            headers={
                "Content-Type": "application/json",
                "Authorization": f"Bearer {os.environ['STRAPI_TOKEN']}",
            },
        )
        strapi_etf_market_data = json.loads(strapi_etf_market_indices.content)
        if strapi_etf_market_indices.status_code == status.HTTP_200_OK:
            data = json.dumps(entry_dict)
            logger.info("Market Index Entry Created")
        else:
            message = strapi_etf_market_data["error"]["message"]
            data = InternalServerError(data=message).json()
            logger.error("Failed To Create Market Index Entry")
        return data
