from fastapi import APIRouter

from api.v1.endpoints.base_endpoints import base_router

Router = APIRouter()

Router.include_router(
    base_router,
    prefix="/base",
    tags=["base"],
    responses={404: {"description": "Not found"}},
)
