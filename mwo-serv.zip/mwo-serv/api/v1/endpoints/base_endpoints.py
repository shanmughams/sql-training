from fastapi import APIRouter

base_router = APIRouter()
