import os
from typing import Any, Callable

from fastapi import Request, Response
from fastapi_cache import Backend, FastAPICache
from fastapi_cache.backends.redis import RedisBackend
from redis import asyncio as aioredis


def redis_cache_backend_with_initialization() -> Backend:
    redis = aioredis.from_url(
        os.environ["REDIS_URL"], encoding="utf8", decode_responses=True
    )
    FastAPICache.init(RedisBackend(redis), prefix="fastapi-cache", expire=60)
    return FastAPICache.get_backend()


def redis_backend() -> Backend:
    return FastAPICache.get_backend()


def key_builder(
    func: Callable,
    namespace: str = "",
    request: Request | None = None,
    response: Response | None = None,
    *args: Any,
    **kwargs: Any,
) -> str:
    if request:
        path_params = request.path_params
        ticker = path_params.get("ticker", None)
        if ticker:
            return f"{ticker}_{namespace}"
    return namespace
