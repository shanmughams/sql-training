from fastapi import Request
from starlette.middleware.base import BaseHTTPMiddleware, RequestResponseEndpoint
from starlette.responses import Response

from core.logger import logger


class LoggingMiddleware(BaseHTTPMiddleware):
    async def dispatch(
        self, request: Request, call_next: RequestResponseEndpoint
    ) -> Response:
        request_log_dict = {
            "url": request.url,
            "method": request.method,
            "path_params": request.path_params,
            "query_params": request.query_params,
        }
        logger.info(request_log_dict)
        response = await call_next(request)
        # Add custom processing here
        return response
