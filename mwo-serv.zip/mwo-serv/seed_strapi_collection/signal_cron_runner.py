import asyncio

from api.v1.crons.rsi_signals import signals_cron
from services.strapi_service import get_current_tickers_bulk

async def run_cron() -> None:
    # res = await signals_cron()
    # res  = await get_rsi_signals_for_days(300)
    res = await get_current_tickers_bulk()
    print(res)


asyncio.run(run_cron())
