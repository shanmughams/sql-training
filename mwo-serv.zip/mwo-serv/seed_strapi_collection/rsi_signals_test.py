import asyncio

from services.strapi_service import get_all_open_buys_signals


async def run_cron() -> None:
    # res = await get_current_tickers_bulk()
    # res = await get_rsi_signals_on_buy_threshold()
    # res = await get_rsi_signals_on_buy_threshold_pagination()
    res = await get_all_open_buys_signals()
    print(res)


asyncio.run(run_cron())
