import asyncio

from seed_strapi_collection.rsi_signal_loader import get_rsi_signals_for_days


async def run_cron() -> None:
    res = await get_rsi_signals_for_days(366)
    print(res)


asyncio.run(run_cron())
