import asyncio
from typing import Any, Dict, List

import httpx

from core.config import settings
from utils.util import get_strapi_headers

# Define your Strapi instance URL and API token

api_token = "YOUR_API_TOKEN"


async def get_current_previous_buy_signals_set() -> List:
    ids_to_update = []
    # api_params: Dict[str, Any] = {
    #     "pagination[pageSize]": str(100),
    #     "pagination[page]": str(1),
    #     "filters[$or][0][current_buy_signal][$notNull]": True,
    #     "filters[$or][1][previous_buy_signal][$notNull]": True,
    #     "fields[0]": "id"
    # }
    ids_to_update = []
    signals_list = []
    api_params: Dict[str, Any] = {
        "pagination[pageSize]": str(100),
        "pagination[page]": str(1),
        "filters[$or][0][current_buy_signal][$notNull]": True,
        "filters[$or][1][previous_buy_signal][$notNull]": True,
        "fields[0]": "id",
        "fields[1]": "current_buy_signal",
        "fields[2]": "previous_buy_signal",
    }
    strapi_api_headers = get_strapi_headers()
    async with httpx.AsyncClient() as client:
        while True:
            response = await client.get(
                settings.strapi_signals_endpoint,
                headers=strapi_api_headers,
                params=api_params,
            )
            response_data = response.json()
            data = response_data.get("data", [])
            # ids_to_update.extend(item["id"] for item in data)
            for item in data:
                signal_info = {
                    "id": item["id"],
                    "current_buy_signal": item.get("attributes", {}).get(
                        "current_buy_signal"
                    ),
                    "previous_buy_signal": item.get("attributes", {}).get(
                        "previous_buy_signal"
                    ),
                }
                signals_list.append(signal_info)
                ids_to_update.append(item["id"])

            pagination = response_data.get("meta", {}).get("pagination", {})
            current_page = pagination.get("page", 1)
            page_count = pagination.get("pageCount", 1)

            if current_page >= page_count:
                break

            api_params["pagination[page]"] = str(current_page + 1)

    # return ids_to_update
    return {"ids_to_update": ids_to_update, "signals_list": signals_list}


# Function to update the fields to null asynchronously
async def update_signals_async(entry_id):
    url = f"{settings.strapi_signals_endpoint}/{entry_id}"
    headers = get_strapi_headers()
    payload = {"data": {"current_buy_signal": None, "previous_buy_signal": None}}
    async with httpx.AsyncClient() as client:
        response = await client.put(url, headers=headers, json=payload)
        return response.json()


# Asynchronous function to update all entries
async def update_all_entries(entry_ids):
    tasks = [update_signals_async(entry_id) for entry_id in entry_ids]
    results = await asyncio.gather(*tasks)
    return results


# Main function to get IDs and update entries
async def main():
    ids_to_update = await get_current_previous_buy_signals_set()
    # results = await update_all_entries(ids_to_update)
    results = await update_all_entries(ids_to_update.get("ids_to_update"))
    print(results)


# Run the main function
if __name__ == "__main__":
    asyncio.run(main())
