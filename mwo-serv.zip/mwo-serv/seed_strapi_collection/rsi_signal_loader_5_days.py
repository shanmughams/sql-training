import asyncio

from seed_strapi_collection.rsi_signal_loader import get_rsi_signals_for_days


async def run_cron_for_days() -> None:
    res = await get_rsi_signals_for_days(9)
    print(res)


asyncio.run(run_cron_for_days())
