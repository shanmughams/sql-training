import glob
import os
from datetime import datetime

import pandas as pd
from dateutil.relativedelta import relativedelta
from sqlalchemy import create_engine

# Directory containing the CSV files
directory_path = "../resources"
log_file_path = "ticker-price-load.log"

# Database connection settings
db_user = "abhishek"
db_password = "novell"
db_host = "localhost"
db_port = "5432"
db_name = "api"
table_name = "intrinio_ticker_prices"

# Create a connection to the PostgreSQL database
engine = create_engine(
    f"postgresql://{db_user}:{db_password}@{db_host}:{db_port}/{db_name}"
)

# Get the list of all CSV files in the directory
csv_files = glob.glob(os.path.join(directory_path, "*.csv"))

# Get the date 60 months ago
sixty_months_ago = datetime.now() - relativedelta(months=60)

# List of tickers to save
tickers_to_save = [
    "GEO",
    "TTGT",
    "CASH",
    "UMH",
    "BFH",
    "MFA",
    "BANF",
    "FCPT",
    "EQBK",
    "GSBC",
    "SBRA",
    "EFSC",
    "BRSP",
    "IIPR",
    "GNL",
    "DCOM",
    "SSB",
    "CLOV",
    "BY",
    "OFC",
    "STT",
    "TRST",
]

tickers_to_save.append("SPY")
# tickers_to_save = ['SPY']

current_datetime = datetime.now().strftime("%Y-%m-%d_%H-%M-%S")
report_file_name = os.path.join("reports", f"ticker_price_{current_datetime}.txt")

# Ensure the directory exists
os.makedirs(os.path.dirname(report_file_name), exist_ok=True)
with open(report_file_name, "w") as log_file:
    total_records_inserted = 0  # Initialize the total records counter
    # Iterate through all CSV files and process them
    for file_path in csv_files:
        print(f"Processing file: {file_path}")
        log_file.write(f"Processing file: {file_path}\n")

        # Read the CSV file
        df = pd.read_csv(file_path)

        # Convert DATE column to datetime
        df["DATE"] = pd.to_datetime(df["DATE"])

        # Filter data for the last 60 months and for specific tickers
        filtered_dfs = []
        for ticker, group in df.groupby("TICKER"):
            if ticker in tickers_to_save:
                max_date = group["DATE"].max()
                min_date = max_date - relativedelta(months=60)
                filtered_dfs.append(group[group["DATE"] >= min_date])
        # Concatenate filtered data if any exists
        if filtered_dfs:
            filtered_df = pd.concat(filtered_dfs, ignore_index=True)

            # Print and log the number of records inserted from this file
            record_count = len(filtered_df)
            print(
                f"Records inserted from {os.path.basename(file_path)}: {record_count}"
            )
            log_file.write(f"Records inserted: {record_count}\n")

            # Count the number of records for each ticker symbol and log them
            ticker_counts = filtered_df["TICKER"].value_counts()
            for ticker, count in ticker_counts.items():
                print(f"{ticker}: {count} records")
                log_file.write(f"{ticker}: {count} records\n")

            # Ensure the DataFrame columns match the target table columns
            filtered_df.columns = [col.lower() for col in filtered_df.columns]
            filtered_df.rename(
                columns={
                    "security_id": "security_id",
                    "company_id": "company_id",
                    "name": "name",
                    "cik": "cik",
                    "ticker": "ticker",
                    "figi": "figi",
                    "composite_figi": "composite_figi",
                    "comp_ticker": "comp_ticker",
                    "exch_ticker": "exch_ticker",
                    "date": "date",
                    "type": "type",
                    "frequency": "frequency",
                    "open": "open",
                    "high": "high",
                    "low": "low",
                    "close": "close",
                    "volume": "volume",
                    "adj_open": "adj_open",
                    "adj_high": "adj_high",
                    "adj_low": "adj_low",
                    "adj_close": "adj_close",
                    "adj_volume": "adj_volume",
                    "adj_factor": "adj_factor",
                    "ex_dividend": "ex_dividend",
                    "split_ratio": "split_ratio",
                    "change": "change",
                    "percent_change": "percent_change",
                    "fifty_two_week_high": "fifty_two_week_high",
                    "fifty_two_week_low": "fifty_two_week_low",
                },
                inplace=True,
            )

            # Store the filtered data in the PostgreSQL table
            try:
                filtered_df.to_sql(table_name, engine, if_exists="append", index=False)
                total_records_inserted += record_count
            except Exception as e:
                print("An error occurred:", e)
                log_file.write(f"An error occurred: {e}\n")
        else:
            print(f"No data to insert for file: {os.path.basename(file_path)}")
            log_file.write(
                f"No data to insert for file: {os.path.basename(file_path)}\n"
            )

    # Print and log the total number of records inserted
    print(f"Total records inserted: {total_records_inserted}")
    log_file.write(f"Total records inserted: {total_records_inserted}\n")
