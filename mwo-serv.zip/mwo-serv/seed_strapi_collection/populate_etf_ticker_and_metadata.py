import asyncio
import os
import time
from typing import Any, Dict, List

import aiohttp
import httpx

intrinio_etf_url = "https://api-v2.intrinio.com/etfs?page_size=8000"
intrinio_etf_metadata_url = "https://api-v2.intrinio.com/etfs"

strapi_etf_ticker_url = f"{os.environ['STRAPI_URL']}/api/etf-tickers"
strapi_etf_ticker_metadata_url = f"{os.environ['STRAPI_URL']}/api/etf-tickers-metadata"

sem = asyncio.Semaphore(9)


async def fetch_etfs() -> Dict:
    """
    Fetch 8000 Etfs From Intrinio
    """
    async with httpx.AsyncClient() as client:
        etfs_response = await client.get(
            intrinio_etf_url,
            headers={
                "Content-Type": "application/json",
                "Authorization": f"Bearer {os.environ['INTRINIO_API_KEY']}",
            },
        )
        etfs_response.raise_for_status()
        etf_datas_dict = etfs_response.json()
        return etf_datas_dict


async def fetch_symbol_metadata(session: Any, symbol: str) -> Dict:
    """
    Fetch Etfs Metadata from Intrinio
    @param session: aiohttp session
    @param symbol: str
    @return: Dict
    """
    async with sem:
        async with session.get(f"{intrinio_etf_metadata_url}/{symbol}") as response:
            response.raise_for_status()
            data = await response.json()
            return data


async def post_ticker_metadata_into_strapi(session: Any, result: dict) -> Any:
    """
    Post Etfs Metadata to Strapi
    @param session: aiohttp session
    @param result: dict
    @return: dict
    """
    async with session.post(
        strapi_etf_ticker_metadata_url,
        json={
            "data": {
                "etf_id": result["id"],
                "name": result["name"],
                "ticker": result["ticker"],
                "figi_ticker": result["figi_ticker"],
                "share_class_figi": result["share_class_figi"],
                "ric": result["ric"],
                "isin": result["isin"],
                "sedol": result["sedol"],
                "exchange_mic": result["exchange_mic"],
                "description": result["description"],
                "is_live_listed": result["is_live_listed"],
                "asset_class": result["asset_class"],
                "other_asset_types": result["other_asset_types"],
                "market_cap_range": result["market_cap_range"],
                "growth_value_tilt": result["growth_value_tilt"],
                "sector": result["sector"],
                "number_of_holdings": result["number_of_holdings"],
                "index_ticker": result["index_ticker"],
                "listing_currency": result["listing_currency"],
                "listing_country_code": result["listing_country_code"],
            }
        },
    ) as response:
        response.raise_for_status()
        data = await response.json()
        return data


async def fetch_all_symbol_metadata() -> List:
    """
    Fetch All Etfs Metadata
    @return: List
    """
    headers = {
        "Authorization": f"Bearer {os.environ['INTRINIO_API_KEY']}",
        "Content-Type": "application/json",
    }
    async with aiohttp.ClientSession(headers=headers) as session:
        tasks = []
        etfs_response = await fetch_etfs()
        etfs = etfs_response["etfs"]
        start_time_ticker = time.time()
        etf_ticker_response = await post_all_ticker_into_strapi(etfs=etfs)
        end_time_ticker = time.time()
        print(
            f"Inserted {len(etf_ticker_response)} records into Strapi Etf Ticker "
            f"Collection in {end_time_ticker - start_time_ticker} seconds"
        )
        for etf in etfs:
            symbol = etf["ticker"]
            task = asyncio.create_task(fetch_symbol_metadata(session, symbol))
            tasks.append(task)
        result = await asyncio.gather(*tasks)
        return result


async def post_ticker_into_strapi(session: Any, etf: dict) -> Dict:
    """
    Post-Ticker to Strapi
    @param session: aiohttp session
    @param etf: dict
    @return: dict
    """
    async with session.post(
        strapi_etf_ticker_url,
        json={
            "data": {
                "etf_id": etf["id"],
                "name": etf["name"],
                "ticker": etf["ticker"],
                "figi_ticker": etf["figi_ticker"],
                "ric": etf["ric"],
                "isin": etf["isin"],
                "sedol": etf["sedol"],
                "exchange_mic": etf["exchange_mic"],
            }
        },
    ) as response:
        response.raise_for_status()
        data = await response.json()
        return data


async def post_all_ticker_into_strapi(etfs: List[Dict]) -> Any:
    """
    Post All Tickers into Strapi
    @param etfs: List
    @return: Any
    """
    tasks = []
    headers = {
        "Authorization": f"Bearer {os.environ['STRAPI_TOKEN']}",
        "Content-Type": "application/json",
    }
    async with aiohttp.ClientSession(headers=headers) as session:
        for etf in etfs:
            task = asyncio.create_task(post_ticker_into_strapi(session, etf))
            tasks.append(task)
        response = await asyncio.gather(*tasks)
        return response


async def post_all_ticker_metadata_into_strapi(results: List[Dict]) -> Any:
    """
    Post All Ticker Metadata into Strapi
    @param results: List
    @return: Any
    """
    tasks = []
    headers = {
        "Authorization": f"Bearer {os.environ['STRAPI_TOKEN']}",
        "Content-Type": "application/json",
    }
    async with aiohttp.ClientSession(headers=headers) as session:
        for result in results:
            task = asyncio.create_task(
                post_ticker_metadata_into_strapi(session, result)
            )
            tasks.append(task)
        response = await asyncio.gather(*tasks)
        return response


async def main() -> None:
    start_time_total = time.time()
    results = await fetch_all_symbol_metadata()
    start_time_etf_ticker_metadata = time.time()
    etf_ticker_metadata_response = await post_all_ticker_metadata_into_strapi(results)
    end_time_etf_ticker_metadata = time.time()
    end_time_total = time.time()
    print(
        f"Inserted {len(etf_ticker_metadata_response)} records into strapi All ticker Metadata collection "
        f"in {end_time_etf_ticker_metadata - start_time_etf_ticker_metadata} seconds"
    )
    print(
        f"start_time_total: {start_time_total} end_time_total: {end_time_total} "
        f"total_time_taken {end_time_total - start_time_total} seconds"
    )


if __name__ == "__main__":
    asyncio.run(main())
