import os
import warnings
from contextlib import asynccontextmanager
from typing import AsyncGenerator

from fastapi import FastAPI
from fastapi_cache import FastAPICache
from fastapi_cache.backends.redis import RedisBackend
from redis import Redis
from redis import asyncio as aioredis
from rq_scheduler import Scheduler
from starlette.middleware import Middleware
from starlette.middleware.cors import CORSMiddleware
from starlette.middleware.trustedhost import TrustedHostMiddleware

from api.v1.crons.etf_indices import etf_market_indices
from api.v1.crons.rsi_signals import signals_cron
from api.v1.router import Router
from core.config import settings
from db.session import sessionmanager
from middlewares.logging_middleware import LoggingMiddleware

warnings.filterwarnings("ignore", category=FutureWarning)

origins = [
    "http://44.207.227.49:3000/",
    "http://52.5.158.226:1337/",
    "http://localhost:8000/",
    "http://127.0.0.1:8000/",
    "http://18.213.52.35:8000/",
]


@asynccontextmanager
async def lifespan(_app: FastAPI) -> AsyncGenerator[None, None]:
    """
    Function that handles startup and shutdown events.
    To understand more, read https://fastapi.tiangolo.com/advanced/events/
    """
    redis = aioredis.from_url(
        os.environ["REDIS_URL"], encoding="utf8", decode_responses=True
    )
    FastAPICache.init(RedisBackend(redis), prefix="fastapi-cache", expire=60)
    tickers = ["SPY", "DIA", "QQQ", "IWM", "IEF", "GLD"]
    indices_queue = "indices_queue"
    etf_indices_scheduler = Scheduler(queue_name=indices_queue, connection=Redis())
    etf_indices_scheduler.cron(
        cron_string="*/15 8-17 * * *",
        func=etf_market_indices,
        kwargs={"tickers": tickers},
        queue_name=indices_queue,
        description="Etf Market Index Queue",
    )
    signal_queue = "signals_queue"
    signals_scheduler = Scheduler(queue_name=signal_queue, connection=Redis())
    signals_scheduler.cron(
        cron_string="0 13 * * * ",
        func=signals_cron,
        queue_name=signal_queue,
        timeout="30m",
        description="Signals Queue",
    )
    yield
    if sessionmanager._engine is not None:
        # Close the DB connection
        await sessionmanager.close()


app = FastAPI(
    lifespan=lifespan,
    title=settings.project_name,
    description=settings.description,
    version=settings.project_version,
    openapi_url=settings.openapi_url,
    docs_url=settings.docs_url,
    redoc_url=settings.redoc_url,
    root_path=settings.root_path,
    openapi_version=settings.openapi_version,
    middlewares=[Middleware(LoggingMiddleware)],
)

app.add_middleware(
    TrustedHostMiddleware,
    allowed_hosts=[
        "44.207.227.49",
        "52.5.158.226",
        "127.0.0.1",
        "localhost",
        "18.213.52.35",
    ],
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=origins,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

app.include_router(Router)
