import re
from datetime import datetime, timedelta
from typing import Any, Dict, List

from core.logger import logger
from utils.constants import DATE_TIME_FORMAT


def is_valid_buy_signal(signal_buy_data: Dict, signal_sell_data: Dict) -> bool:
    """
       For each buy signal, the  method checks if there is a corresponding sell signal
    in resultSells that matches the following conditions:
    1 - The sell signal has the same symbol as the buy signal.
    2 - If the sell signal has a stop loss and the sell date plus 30 days is less than or equal to the buy date,
                or
        the sell signal does not have a stop loss and the sell date is less than or equal to the buy date.
    3 - The sell date is not within the last 18 days from the current date.
    :param signal_buy_data:
    :type signal_buy_data:
    :param signal_sell_data:
    :type signal_sell_data:
    :return:
    :rtype:
    """
    signal_sell = signal_sell_data["attributes"]
    signal_buy = signal_buy_data["attributes"]

    # current_date = datetime.now(pytz.utc)
    current_date = datetime.now()
    past_18_current_date = current_date - timedelta(days=18)
    if not signal_sell["sell_date"] or not signal_buy["buy_date"]:
        return False
    sell_date = datetime.strptime(signal_sell["sell_date"], DATE_TIME_FORMAT)
    future_30_sell_date = datetime.strptime(
        signal_sell["sell_date"], DATE_TIME_FORMAT
    ) + timedelta(days=30)
    buy_date = datetime.strptime(signal_buy["buy_date"], DATE_TIME_FORMAT)

    condition1 = signal_sell["symbol"] == signal_buy["symbol"]
    condition2 = signal_sell["stop_loss"] and (future_30_sell_date <= buy_date)
    condition3 = not signal_sell["stop_loss"] and (sell_date <= buy_date)
    condition4 = past_18_current_date <= sell_date
    exists = condition1 and not (condition2 or condition3) and not condition4
    return exists


def filter_signals_on_buys_without_sells(
    recent_sell_signals: List[Dict], result_buy_signals: List[Dict]
) -> List[Dict]:
    """
    If NO such sell signal exists (!exists), the buy signal is added to resultBuysNoSell.
    :param recent_sell_signals:
    :type recent_sell_signals:
    :param result_buy_signals:
    :type result_buy_signals:
    :return:
    :rtype:
    """
    result_buys_no_sell = []
    for buy_signal in result_buy_signals:
        exists = False
        for sell_signal in recent_sell_signals:
            if is_valid_buy_signal(buy_signal, sell_signal):
                exists = True
                break

        if not exists:
            result_buys_no_sell.append(buy_signal)
    return result_buys_no_sell


async def parse_signal_data(rsi_signals_list: List[Dict]) -> List[Dict]:
    """

    :param rsi_signals_list:
    :type rsi_signals_list:
    :return:
    :rtype:
    """
    signal_to_be_updated = []
    table_data: List[Dict] = []
    for rsi_signal_data in rsi_signals_list:
        rsi_signal = rsi_signal_data["attributes"]
        min_score = await get_min_score(rsi_signal)
        if rsi_signal.get("sell_date") or (
            min_score >= 4 and is_average_within_price_range(rsi_signal)
        ):
            exists = any(
                table["symbol"] == rsi_signal["symbol"] for table in table_data
            )

            if not exists:
                rsi_signal["opportunity_score"] = await get_opportunity_score(
                    rsi_signal
                )
                if rsi_signal.get("stop_loss"):
                    rsi_signal["sell_date_formatted"] += "†"
                buy_date = datetime.strptime(
                    rsi_signal["buy_date"], "%Y-%m-%dT%H:%M:%S.%fZ"
                )
                current_date = datetime.now()
                rsi_signal["days_in_trade"] = (current_date - buy_date).days
                if rsi_signal.get("sell_date"):
                    sell_date = datetime.strptime(
                        rsi_signal["sell_date"], "%Y-%m-%dT%H:%M:%S.%fZ"
                    )
                    rsi_signal["days_in_trade"] = (sell_date - buy_date).days

                if (
                    rsi_signal["percent_return"] is not None
                    and rsi_signal["days_in_trade"] is not None
                ):
                    rsi_signal["annualized_return"] = (
                        (365 / rsi_signal["days_in_trade"])
                        * (rsi_signal["percent_return"] / 100)
                    ) * 100
                else:
                    logger.warn(
                        f"percent_return : {rsi_signal["percent_return"]}, "
                        f"days_in_trade : {rsi_signal["days_in_trade"]}"
                    )

                table_data.append(rsi_signal)
                signal_to_be_updated.append(rsi_signal_data)
    return signal_to_be_updated


def is_average_within_price_range(signal: Dict) -> bool:
    """
    Check if the average price is between the minimum and maximum prices,
    and none of the prices are None.

    Parameters:
    signal (dict): A dictionary containing 'min_price', 'average', and 'max_price' keys.

    Returns:
    bool: True if min_price <= average <= max_price and none of the values are None, False otherwise.
    """
    try:
        min_price = signal.get("min_price")
        average = signal.get("average")
        max_price = signal.get("max_price")

        # Check if any of the values are None
        if min_price is None or average is None or max_price is None:
            return False

        return min_price <= average <= max_price
    except KeyError as e:
        logger.warning(f"Missing key in signal dictionary: {e}")
        return False
    except TypeError:
        logger.warning(
            "Invalid input. The signal should be a dictionary with numeric values."
        )
        return False


def transform_ticker_name(orig_name: str) -> str:
    """
        Changes the ticker name if it has some of the below words in it

    :param orig_name:
    :type orig_name:
    :return:
    :rtype:
    """
    if not orig_name or len(orig_name) == 0:
        return orig_name

    suffixes = [
        r"\sincorporated",
        r"\sregistered",
        r"\scorporation",
        r"\scommon\sstock",
        r"\sholdings",
        r"\sads?",
        r"\sadrs?-a?",
        r"\scompany",
        r"\scorp\.?",
        r"\shldgs?",
        r"\sclass\s?[-]?\s?(b|a)",
    ]

    # Create a combined regex pattern
    suffix_pattern = r"({})".format("|".join(suffixes))

    # Remove any suffix at the end of the name
    sanitized_name = re.sub(suffix_pattern + r"$", "", orig_name, flags=re.IGNORECASE)

    # Further remove 'inc' variations and trailing commas
    sanitized_name = re.sub(
        r"(,\sinc\.?|,\sinc| inc\.?)$", "", sanitized_name, flags=re.IGNORECASE
    )
    sanitized_name = re.sub(r",$", "", sanitized_name)

    sanitized_name = sanitized_name.strip()
    if orig_name != sanitized_name:
        logger.debug(f"Original name: {orig_name}, Transformed name: {sanitized_name}")
    return sanitized_name


def is_ticker_name_present(
    ticker_dict: Dict[str, List[str]], ticker: str, name: str
) -> bool:
    """
    Check if a given ticker and name pair is already present in the ticker_dict.

    :param ticker_dict: Dictionary where keys are tickers and values are lists of names.
    :type ticker_dict: Dict[str, List[str]]
    :param ticker: The ticker symbol to check.
    :type ticker: str
    :param name: The name to check.
    :type name: str
    :return: True if the ticker and name pair is present, False otherwise.
    :rtype: bool
    """
    return ticker in ticker_dict and name in ticker_dict[ticker]


def prepare_filter(symbol_ids: List, date: str) -> Dict:
    """
    Prepare Filters
    @param symbol_ids: list
    @param date: str
    """
    return {"symbol_ids": symbol_ids, "date": date}


def get_unique_tickers(
    securities: List[Dict[str, Any]], existing_tickers: Dict[str, list]
) -> List:
    new_securities = []
    for security in securities:
        ticker = str(security.get("ticker", ""))
        name = str(security.get("name", ""))
        if not is_ticker_name_present(existing_tickers, ticker, name):
            new_securities.append(security)

    records_already_present = len(securities) - len(new_securities)
    logger.info(
        f"Current securities count : [{len(securities)}], "
        f" new securities count after existing removed : [{len(new_securities)}], "
        f" Records already present : [{records_already_present}]"
    )
    if new_securities and len(new_securities) == 0:
        logger.info("No New Ticker Details to handle")
        return new_securities
    return new_securities


def map_security_field(securities_to_map: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
    """
    Map id to security_id
    :param securities_to_map:
    :type securities_to_map:
    :return:
    :rtype:
    """
    mapped_securities = [
        {
            "security_id": security["id"],
            "company_id": security.get("company_id"),
            "stock_exchange_id": security.get("stock_exchange_id"),
            "name": transform_ticker_name(str(security.get("name", ""))),
            "code": security.get("code"),
            "currency": security.get("currency"),
            "ticker": security.get("ticker"),
            "composite_ticker": security.get("composite_ticker"),
            "figi": security.get("figi"),
            "composite_figi": security.get("composite_figi"),
            "share_class_figi": security.get("share_class_figi"),
            "primary_listing": security.get("primary_listing"),
        }
        for security in securities_to_map
        if security.get("primary_listing") is True
    ]
    logger.info(
        f"Original Ticker detail list Count : [{len(securities_to_map)}],  "
        f"filtered mapped Ticker detail list Count : [{len(mapped_securities)}]"
    )
    return mapped_securities


def prepare_signal_body(signal: Dict) -> Dict:
    """
    Prepare signal body
    @param signal: Dict
    @return: Dict
    """
    buy_date_formatted = (
        datetime.strptime(signal["BuyDate"], "%Y-%m-%dT%H:%M:%S").strftime("%m-%d-%Y")
        if signal.get("BuyDate")
        else None
    )
    signal_record = {
        "symbol_id": signal["SymbolId"],
        "symbol": signal["Symbol"],
        "symbol_name": signal["SymbolName"],
        "transaction_id": signal["TransactionId"],
        "buy_rsi_threshold": signal["BuyRsiThreshold"],
        "sell_rsi_threshold": signal["SellRsiThreshold"],
        "entry_rsi_buy_date": signal.get("EntryRsiBuyDate"),
        "buy_rsi": signal["BuyRsi"],
        "buy_date": signal["BuyDate"],
        "buy_date_formatted": buy_date_formatted,
        "buy_price": signal["BuyPrice"],
        "entry_rsi_sell_date": signal.get("EntryRsiSellDate"),
        "sell_rsi": signal.get("SellRsi"),
        "old_sell_date": signal.get("SellDate"),
        "old_sell_price": signal.get("SellPrice"),
        "ebitda_diff_positive_percent": signal.get("EbitdaDiffPositivePercent"),
        "ebitda_positive_percent": signal.get("EbitdaPositivePercent"),
        "market_cap": signal.get("MarketCap"),
        "eps_surprise_percent": signal.get("EpsSurprisePercent"),
        "revenue_surprise_percent": signal.get("RevenueSurprisePercent"),
        "importance": signal.get("Importance"),
        "update_date": signal.get("UpdateDate"),
    }
    return signal_record


async def get_min_score(signal: Dict) -> int:
    """
    Get Min Score
    @signal: dict
    """
    min_score = 0
    if (
        signal["ebitda_diff_positive_percent"] is not None
        and signal["ebitda_diff_positive_percent"] >= 80
    ):
        min_score += 1
    if (
        signal["ebitda_positive_percent"] is not None
        and signal["ebitda_positive_percent"] >= 80
    ):
        min_score += 1
    if (
        signal["revenue_surprise_percent"] is not None
        and signal["revenue_surprise_percent"] > 0
    ):
        min_score += 1
    if (
        signal["eps_surprise_percent"] is not None
        and signal["eps_surprise_percent"] > 0
    ):
        min_score += 1
    if signal["importance"] is not None and signal["importance"] >= 4:
        min_score += 1

    return min_score


async def get_opportunity_score(signal: Dict) -> int:
    """
    Get Opportunity Score
    @signal: dict
    @return: dict
    """
    score = 1
    if (
        signal["ebitda_diff_positive_percent"] is not None
        and signal["ebitda_diff_positive_percent"] >= 80
        and signal["ebitda_positive_percent"] is not None
        and signal["ebitda_positive_percent"] >= 80
        and signal["revenue_surprise_percent"] is not None
        and signal["revenue_surprise_percent"] > 0
        and signal["eps_surprise_percent"] is not None
        and signal["eps_surprise_percent"] > 0
        and signal["importance"] is not None
        and float(signal["importance"]) >= 4
    ):
        score += 1

    if (
        signal["ebitda_diff_positive_percent"] is not None
        and signal["ebitda_diff_positive_percent"] >= 100
    ):
        score += 1
    if (
        signal["ebitda_positive_percent"] is not None
        and signal["ebitda_positive_percent"] >= 100
    ):
        score += 1
    if signal["importance"] is not None and signal["importance"] == 5:
        score += 1

    return score
