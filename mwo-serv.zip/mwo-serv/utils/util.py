import json
import logging
import os
from datetime import datetime, timedelta
from typing import Any, Dict, List, Union

import pytz

from utils.constants import JSON_SEED


def compare_datetime(
    date_time_str1: Any,
    date_time_format1: str,
    date_time_str2: Any,
    date_time_format2: str,
    days: int = 0,
) -> bool:
    # Checking if datetime is coming as none
    if not (date_time_str1 and date_time_str2):
        return False
    if days:
        return datetime.strptime(date_time_str1, date_time_format1) >= (
            datetime.strptime(date_time_str2, date_time_format2) - timedelta(days=days)
        )
    return datetime.strptime(date_time_str1, date_time_format1) >= datetime.strptime(
        date_time_str2, date_time_format2
    )


def get_utc_time_str(
    date_time_format: str,
    extra_formatting: int | Any = None,
    past_time: bool | Any = None,
    days_ago: int | Any = None,
) -> str:
    """
    get_utc_time_str
    @param date_time_format: str
    @param extra_formatting: int
    @param past_time: bool
    @param days_ago: int
    @return: str
    """
    current_datetime = datetime.now(pytz.utc)
    if past_time:
        res = (current_datetime - timedelta(days=days_ago)).strftime(date_time_format)
    else:
        res = current_datetime.strftime(date_time_format)
    if extra_formatting:
        res = res[:-extra_formatting] + "Z"
        return res
    else:
        return res


def get_root_dir() -> str:
    """
    get_root_dir
    @return: str
    """
    return os.path.dirname(os.path.abspath(os.path.dirname(__file__)))


def get_resource_dir() -> str:
    """
    get_resource_dir
    @return: str
    """
    return os.path.join(get_root_dir(), "resources")


def read_data_into_json() -> Dict[str, str]:
    """
    read_data_into_json
    @return: Dict[str, str]
    """
    path = os.path.join(get_resource_dir(), JSON_SEED)
    return json.load(open(path))


def write_data_into_json(data: Dict[str, str | bool]) -> None:
    """
    write_data_into_json
    @param data: Dict[str, str]
    @return: None
    """
    path = os.path.join(get_resource_dir(), JSON_SEED)
    json.dump(data, open(path, "w"))


def get_strapi_headers() -> dict[str, str]:
    return {
        "content-type": "application/json",
        "Authorization": f"Bearer {os.environ['STRAPI_TOKEN']}",
    }


def convert_string_to_datetime_obj(
    date_time_str: str, format: str, to_format: Any = None
) -> Any:
    try:
        datetime_obj = datetime.strptime(date_time_str, format)
        if to_format:
            return datetime_obj.strftime(to_format)
        else:
            return datetime_obj
    except Exception as e:
        logging.error(f"{e}")


def check_validity(obj: Any, key: str, value: Any, operator: str) -> bool:
    if operator == ">=":
        if obj[key] and obj[key] >= value:
            return True
    elif operator == ">":
        if obj[key] and obj[key] > value:
            return True
    else:
        raise Exception(f"Operator not supported {operator}")
    return False


def is_non_empty_list(a_list: List) -> bool:
    if a_list and len(a_list) > 0:
        return True

    return False


def is_empty(container: Union[list, set, dict, tuple, None]) -> bool:
    if container is None:
        return True
    if isinstance(container, (list, set, dict, tuple)):
        return len(container) == 0
    # Return False for unsupported types
    return False


def is_non_empty(container: Union[list, set, dict, tuple, None]) -> bool:
    """Check if a list, set, dictionary, or tuple is not None and not empty."""
    if container is None:
        return False
    if isinstance(container, (list, set, dict, tuple)):
        return len(container) > 0
    # Return False for unsupported types
    return False
