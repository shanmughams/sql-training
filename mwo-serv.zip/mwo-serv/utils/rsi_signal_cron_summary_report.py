from typing import Any, Dict, List, Type

from core.logger import logger
from utils.constants import ETF_MARKET_INDICES_CREATE_UPDATE_DATE_TIME_FORMAT
from utils.util import get_utc_time_str


class RSISignalsCronSummaryReport:
    _instance = None

    def __new__(
        cls: Type["RSISignalsCronSummaryReport"], *args: Any, **kwargs: Any
    ) -> Any:
        if not cls._instance:
            cls._instance = super(RSISignalsCronSummaryReport, cls).__new__(
                cls, *args, **kwargs
            )
        return cls._instance

    def __init__(self) -> None:
        if not hasattr(self, "initialized"):
            # Cron Information
            self._cron_start_time_formatted: str = ""
            self._cron_end_time_formatted: str = ""

            # RSI Signals Downloads
            self._rsi_signals_last_update_date_used: str = ""
            self._total_rsi_signals_from_api: int = 0
            self._total_rsi_signals_over_500m_cap: int = 0
            self._total_new_rsi_signals_from_api: int = 0
            self._total_existing_rsi_signals_updated_from_api: int = 0
            self._rsi_signals_with_matching_txn_id: Dict[str, int] = {}  # symbol, count
            self._rsi_signals_with_matching_symbol_buy_date: Dict[str, int] = (
                {}
            )  # symbol, count

            # RSI Signal Processing
            self._total_rsi_signals_on_buy_threshold: int = 0
            self._total_rsi_signals_with_min_score_on_4: int = 0
            self._total_rsi_signals_with_new_symbol_ids: int = 0
            self._total_rsi_signals_on_existing_symbol_ids: int = 0
            self._signals_with_min_score_required: List[str] = []

            # Ticker Prices
            self._ticker_price_download_start_time_formatted: str = ""
            self._ticker_price_download_end_time_formatted: str = ""
            self._ticker_price_download_time_taken: float = 0
            self._ticker_price_download_success: bool = False
            # self._total_ticker_prices_downloaded: int = 0

            # Ticker Details
            self._existing_ticker_details_count: int = 0
            self._new_ticker_details: int = 0
            self._ticker_details_download_time_taken: float = 0

            # Signals Returns
            self._rsi_signals_sell_goal_handled: Dict[str, int] = {}
            self._rsi_signals_stop_loss_handled: Dict[str, int] = {}

            # cron 2 - details for - screen
            self._sell_signals: List[str] = []
            self._buy_signals: List[str] = []

            self.initialized = True

    def add_sell_signals_from_list(self, signals_list: List[Any]) -> None:
        for signal in signals_list:
            self.add_sell_signals(signal["attributes"]["symbol"])

    def add_buy_signals_from_list(self, signals_list: List[Any]) -> None:
        for signal in signals_list:
            self.add_buy_signals(signal["attributes"]["symbol"])

    def add_sell_signals(self, symbol: str) -> None:
        if symbol is not None:
            self._sell_signals.append(symbol)

    @property
    def sell_signals(self) -> List[str]:
        return self._sell_signals

    def add_buy_signals(self, symbol: str) -> None:
        if symbol is not None:
            self._buy_signals.append(symbol)

    @property
    def buy_signals(self) -> List[str]:
        return self._buy_signals

    @property
    def ticker_details_download_time_taken(self) -> float:
        return self._ticker_details_download_time_taken

    @ticker_details_download_time_taken.setter
    def ticker_details_download_time_taken(self, value: float) -> None:
        self._ticker_details_download_time_taken = value

    @property
    def ticker_price_download_success(self) -> bool:
        return self._ticker_price_download_success

    @ticker_price_download_success.setter
    def ticker_price_download_success(self, value: bool) -> None:
        self._ticker_price_download_success = value

    @property
    def ticker_price_download_time_taken(self) -> float:
        return self._ticker_price_download_time_taken

    @ticker_price_download_time_taken.setter
    def ticker_price_download_time_taken(self, value: float) -> None:
        self._ticker_price_download_time_taken = value

    def set_cron_start_time_formatted(self) -> None:
        self._cron_start_time_formatted = get_utc_time_str(
            date_time_format=ETF_MARKET_INDICES_CREATE_UPDATE_DATE_TIME_FORMAT,
            extra_formatting=3,
        )

    @property
    def cron_start_time_formatted(self) -> str:
        return self._cron_start_time_formatted

    def set_cron_end_time_formatted(self) -> None:
        self._cron_end_time_formatted = get_utc_time_str(
            date_time_format=ETF_MARKET_INDICES_CREATE_UPDATE_DATE_TIME_FORMAT,
            extra_formatting=3,
        )

    @property
    def cron_end_time_formatted(self) -> str:
        return self._cron_end_time_formatted

    def set_ticker_price_download_start_time_formatted(self) -> None:
        self._ticker_price_download_start_time_formatted = get_utc_time_str(
            date_time_format=ETF_MARKET_INDICES_CREATE_UPDATE_DATE_TIME_FORMAT,
            extra_formatting=3,
        )

    @property
    def ticker_price_download_start_time_formatted(self) -> str:
        return self._ticker_price_download_start_time_formatted

    def set_ticker_price_download_end_time_formatted(self) -> None:
        self._ticker_price_download_end_time_formatted = get_utc_time_str(
            date_time_format=ETF_MARKET_INDICES_CREATE_UPDATE_DATE_TIME_FORMAT,
            extra_formatting=3,
        )

    @property
    def ticker_price_download_end_time_formatted(self) -> str:
        return self._ticker_price_download_end_time_formatted

    @property
    def rsi_signals_last_update_date_used(self) -> str:
        return self._rsi_signals_last_update_date_used

    @rsi_signals_last_update_date_used.setter
    def rsi_signals_last_update_date_used(self, value: str) -> None:
        self._rsi_signals_last_update_date_used = value

    @property
    def total_rsi_signals_from_api(self) -> int:
        return self._total_rsi_signals_from_api

    @total_rsi_signals_from_api.setter
    def total_rsi_signals_from_api(self, value: int) -> None:
        self._total_rsi_signals_from_api = value

    @property
    def total_rsi_signals_over_500m_cap(self) -> int:
        return self._total_rsi_signals_over_500m_cap

    @total_rsi_signals_over_500m_cap.setter
    def total_rsi_signals_over_500m_cap(self, value: int) -> None:
        self._total_rsi_signals_over_500m_cap = value

    def incr_rsi_signals_over_500m_cap_count(self) -> None:
        self._total_rsi_signals_over_500m_cap += 1

    @property
    def total_new_rsi_signals_from_api(self) -> int:
        return self._total_new_rsi_signals_from_api

    @total_new_rsi_signals_from_api.setter
    def total_new_rsi_signals_from_api(self, value: int) -> None:
        self._total_new_rsi_signals_from_api = value

    def incr_new_rsi_signals_from_api_count(self) -> None:
        self._total_new_rsi_signals_from_api += 1

    @property
    def total_existing_rsi_signals_updated_from_api(self) -> int:
        return self._total_existing_rsi_signals_updated_from_api

    @total_existing_rsi_signals_updated_from_api.setter
    def total_existing_rsi_signals_updated_from_api(self, value: int) -> None:
        self._total_existing_rsi_signals_updated_from_api = value

    def incr_existing_rsi_signals_updated_from_api_count(self) -> None:
        self._total_existing_rsi_signals_updated_from_api += 1

    def add_signals_with_min_score_required(self, symbol: str) -> None:
        if symbol is not None:
            self._signals_with_min_score_required.append(symbol)

    @property
    def signals_with_min_score_required(self) -> List[str]:
        return self._signals_with_min_score_required

    def add_rsi_signals_with_matching_txn_id(self, symbol: str) -> None:
        if symbol in self._rsi_signals_with_matching_txn_id:
            self._rsi_signals_with_matching_txn_id[symbol] += 1
        else:
            self._rsi_signals_with_matching_txn_id[symbol] = 1

    def get_rsi_signals_with_matching_txn_id_for_symbol(
        self, symbol: str
    ) -> int | None:
        if symbol in self._rsi_signals_with_matching_txn_id:
            return self._rsi_signals_with_matching_txn_id[symbol]
        else:
            return None

    def get_total_rsi_signals_with_matching_txn_id(self) -> int:
        return sum(self._rsi_signals_with_matching_txn_id.values())

    def add_rsi_signals_with_matching_symbol_buy_date(self, symbol: str) -> None:
        if symbol in self._rsi_signals_with_matching_symbol_buy_date:
            self._rsi_signals_with_matching_symbol_buy_date[symbol] += 1
        else:
            self._rsi_signals_with_matching_symbol_buy_date[symbol] = 1

    def get_rsi_signals_with_matching_symbol_buy_date_for_symbol(
        self, symbol: str
    ) -> int | None:
        if symbol in self._rsi_signals_with_matching_symbol_buy_date:
            return self._rsi_signals_with_matching_symbol_buy_date[symbol]
        else:
            return None

    def get_total_rsi_signals_with_matching_symbol_buy_date(self) -> int:
        return sum(self._rsi_signals_with_matching_symbol_buy_date.values())

    @property
    def total_rsi_signals_on_buy_threshold(self) -> int:
        return self._total_rsi_signals_on_buy_threshold

    @total_rsi_signals_on_buy_threshold.setter
    def total_rsi_signals_on_buy_threshold(self, value: int) -> None:
        self._total_rsi_signals_on_buy_threshold = value

    @property
    def total_rsi_signals_with_min_score_on_4(self) -> int:
        return self._total_rsi_signals_with_min_score_on_4

    @total_rsi_signals_with_min_score_on_4.setter
    def total_rsi_signals_with_min_score_on_4(self, value: int) -> None:
        self._total_rsi_signals_with_min_score_on_4 = value

    def incr_rsi_signals_with_min_score_on_4_count(self) -> None:
        self._total_rsi_signals_with_min_score_on_4 += 1

    @property
    def total_rsi_signals_with_new_symbol_ids(self) -> int:
        return self._total_rsi_signals_with_new_symbol_ids

    @total_rsi_signals_with_new_symbol_ids.setter
    def total_rsi_signals_with_new_symbol_ids(self, value: int) -> None:
        self._total_rsi_signals_with_new_symbol_ids = value

    def incr_rsi_signals_with_new_symbol_ids_count(self) -> None:
        self._total_rsi_signals_with_new_symbol_ids += 1

    @property
    def total_rsi_signals_on_existing_symbol_ids(self) -> int:
        return self._total_rsi_signals_on_existing_symbol_ids

    @total_rsi_signals_on_existing_symbol_ids.setter
    def total_rsi_signals_on_existing_symbol_ids(self, value: int) -> None:
        self._total_rsi_signals_on_existing_symbol_ids = value

    def incr_rsi_signals_on_existing_symbol_ids(self) -> None:
        self._total_rsi_signals_on_existing_symbol_ids += 1

    @property
    def existing_ticker_details_count(self) -> int:
        return self._existing_ticker_details_count

    @existing_ticker_details_count.setter
    def existing_ticker_details_count(self, value: int) -> None:
        self._existing_ticker_details_count = value

    @property
    def new_ticker_details(self) -> int:
        return self._new_ticker_details

    @new_ticker_details.setter
    def new_ticker_details(self, value: int) -> None:
        self._new_ticker_details = value

    @property
    def rsi_signals_sell_goal_handled(self) -> Dict:
        return self._rsi_signals_sell_goal_handled

    @property
    def rsi_signals_stop_loss_handled(self) -> Dict:
        return self._rsi_signals_stop_loss_handled

    def add_rsi_signals_sell_goal_handled(self, symbol: str) -> None:
        if not isinstance(symbol, str):
            logger.warning(f"Symbol invalid - {symbol}")
            return

        if symbol in self._rsi_signals_sell_goal_handled:
            self._rsi_signals_sell_goal_handled[symbol] += 1
        else:
            self._rsi_signals_sell_goal_handled[symbol] = 1

    def get_rsi_signals_sell_goal_handled_for_symbol(self, symbol: str) -> int | None:
        if symbol in self._rsi_signals_sell_goal_handled:
            return self._rsi_signals_sell_goal_handled[symbol]
        else:
            return None

    def get_total_rsi_signals_sell_goal_handled(self) -> int:
        return sum(self._rsi_signals_sell_goal_handled.values())

    def get_sell_goal_handled_rsi_signals(self) -> list:
        return list(self._rsi_signals_sell_goal_handled.keys())

    def add_rsi_signals_stop_loss_handled(self, symbol: str) -> None:
        if not isinstance(symbol, str):
            logger.warning(f"Symbol invalid - {symbol}")
            return

        if symbol in self._rsi_signals_stop_loss_handled:
            self._rsi_signals_stop_loss_handled[symbol] += 1
        else:
            self._rsi_signals_stop_loss_handled[symbol] = 1

    def get_rsi_signals_stop_loss_handled_for_symbol(self, symbol: str) -> int | None:
        if symbol in self._rsi_signals_stop_loss_handled:
            return self._rsi_signals_stop_loss_handled[symbol]
        else:
            return None

    def get_total_rsi_stop_loss_handled(self) -> int:
        return sum(self._rsi_signals_stop_loss_handled.values())

    def get_stop_loss_handled_rsi_signals(self) -> list:
        return list(self._rsi_signals_stop_loss_handled.keys())

    def log_cron_summary_report(self) -> None:

        logger.info(
            "\n\n--------------------------------------RSI Signals Cron Report-------------------------------------"
            f"\nCron Information:\n"
            f"\tStart time - [{self.cron_start_time_formatted}], end time - [{self.cron_end_time_formatted}]\n"
            f"\n"
            f"RSI Signals Downloads stats :\n"
            f"\tLast Update date Used  - [{self.rsi_signals_last_update_date_used}], "
            f" Total Signals received from Tradesmith RSI API - [{self.total_rsi_signals_from_api}]\n"
            f"\tSignals over 500 Mn Cap - [{self.total_rsi_signals_over_500m_cap}], \n"
            f"\tTotal New RSI Signals from API - [{self.total_new_rsi_signals_from_api}] "
            f" Existing Signals Updated - [{self.total_existing_rsi_signals_updated_from_api}], \n"
            f"\tSignals with matching Txn IDs - [{self.get_total_rsi_signals_with_matching_txn_id()}]"
            f" Signals with matching symbol Buy Date - [{self.get_total_rsi_signals_with_matching_symbol_buy_date()}]\n"
            f"\n"
            f"RSI Signal Processing stats:\n"
            f"\tTotal RSI Signals On Buy Threshold - [{self.total_rsi_signals_on_buy_threshold}], "
            f" Total RSI Signals with Min Score >= 4 - [{self.total_rsi_signals_with_min_score_on_4}]\n"
            f"\tTotal RSI Signals with new symbol ids - [{self.total_rsi_signals_with_new_symbol_ids}], "
            f" Total RSI Signals on existing symbol ids - [{self.total_rsi_signals_on_existing_symbol_ids}]\n"
            f"\tSymbols with Min Score(>= 4) :\n\t\t [{self.signals_with_min_score_required}]\n"
            f"\n"
            f"Intrinio Ticker Price stats:\n"
            f"\tTicker Price download start time - [{self.ticker_price_download_start_time_formatted}], "
            f" end time - [{self.ticker_price_download_end_time_formatted}]\n"
            f"\tTicker Price Download time - [{self.ticker_price_download_time_taken}] seconds \n"
            # f" Ticker Price Download Success ? - [{self.ticker_price_download_success}]\n"
            f"\n"
            f"Intrinio Ticker Details stats:\n"
            f"\tTotal existing ticker details from DB - [{self.existing_ticker_details_count}], "
            f" Total New ticker details - [{self.new_ticker_details}]\n"
            f"\tTicker Details Download time - [{self.ticker_details_download_time_taken}] seconds\n"
            f"\n"
            f"RSI Signal Returns stats:\n"
            f"\tTotal RSI Signals Sell Goals Handled - [{self.get_total_rsi_signals_sell_goal_handled()}]:\n"
            f"\tSignals that have Sell Goals Goals handled :\n\t\t [{self.get_sell_goal_handled_rsi_signals()}]\n"
            f"\tTotal RSI Signals Stop Loss Handled - [{self.get_total_rsi_stop_loss_handled()}]\n"
            f"\tSignals that have Stop Loss handled :\n\t\t [{self.get_stop_loss_handled_rsi_signals()}]"
            f"\n"
            f"Buys - Sell Signals stats:\n"
            f"\tSell Signals :\n\t\t {self.sell_signals}:\n"
            f"\tBuys with No Sell - Signals :\n\t\t {self.buy_signals}\n"
            f"\n"
            "\n--------------------------------------------------------------------------------------------------\n\n"
        )


cron_report = RSISignalsCronSummaryReport()
