ETF_MARKET_INDICES_DATE_FORMAT: str = "%Y-%m-%d"
ETF_MARKET_INDICES_CREATE_UPDATE_DATE_TIME_FORMAT: str = "%Y-%m-%dT%H:%M:%S.%f"

MARKET_CAP_LIMIT: int = 500000000
SIGNAL_MIN_SCORE = 4
STRAPI_BULK_CHUNK_SIZE = 2114

JSON_SEED: str = "seed.json"

INTRINIO_API_RATE_LIMIT_SLEEP_SECONDS = 60
INTRINIO_API_MAX_RETRIES = 3

STRAPI_API_MAX_RETRIES = 3

SYMBOL_CODES = ["DR", "ETN", "ETF", "EQS"]
SPY_ETF_SYMBOL = "SPY"

DATE_TIME_FORMAT: str = "%Y-%m-%dT%H:%M:%S.%fZ"
DATE_FORMAT: str = "%Y-%m-%d"
INTRINIO_ETF_PRICE_ENDPOINT: str = (
    "https://api-v2.intrinio.com/securities/{ticker}/prices"
)
INTRINIO_ETF_REALTIME_PRICE_ENDPOINT: str = (
    "https://api-v2.intrinio.com/securities/{ticker}/prices/realtime"
)
INTRINIO_BULK_DOWNLOAD_URL: str = "https://api-v2.intrinio.com/bulk_downloads/links"

INTRINIO_TICKER_DETAILS_URL: str = (
    "https://api-v2.intrinio.com/securities?page_size=8000&currency=USD&code={code}&api_key={api_key}"
)

INTRINIO_SECURITY_DETAILS_URL: str = "https://api-v2.intrinio.com/securities/{ticker}"

TRADESMITH_RSI_AUTHENTICATE_ENDPOINT: str = (
    "https://rsi-api.tradesmith.com/api/authenticate"
)
TRADESMITH_RSI_SIGNALS_WITH_DATE_ENDPOINT: str = (
    "https://rsi-api.tradesmith.com/api/rsisignals/signals/{update_date}/true"
)
TRADESMITH_RSI_SIGNALS_ENDPOINT: str = (
    "https://rsi-api.tradesmith.com/api/rsisignals/signals/true"
)
