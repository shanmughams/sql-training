# How-to Setup pycharm

```
1. Setup File Watchers for below modules
    1. flake8
    2. mypy
    3. black
    4. autoflake
    5. isort
    
2. Setup above watchers in On save Actions
3. Enable Reformat Code and Optimize Import under on save actions
4. Set Code Autosave time to 10 secs
```


# Run DB And Pgadmin inside Docker

```
- Run DB in docker 
   docker run –name pgsql-dev -e POSTGRES_PASSWORD=Welcome4$ -p 5432:5432 Postgres
- Exec into db container
    docker exec -it pgsql-dev bash
    psql -h localhost _U postgres
- Run pgadmin inside docker container
    docker run -e ‘PGADMIN_DEFAULT_EMAIL=test@domain.local’ -e ‘PGADMIN_DEFAULT_PASSWORD=test1234’ -p 8080:80 –name pgadmin4-dev dpage/pgadmin4
- Pgadmin Ui should be acessible at http://localhost:8080
- Enter email: test@domain.local password: test1234
- Now Follow Below steps to connect pgadmin with postgres DB
    run docker inspect pgsql-dev
    DB host ip -> go to IPAddress and save it somewhere
    username: postgres
    password: Welcome4$
    manintance databse : postgres
    port: 5432
```

# Run Db in docker
```
docker run --name some-postgres -e POSTGRES_USER=abhishek POSTGRES_PASSWORD=novell POSTGRES_DB=mwo-services -v db_data:/var/lib/postgresql/data -p 5432:5432 -d postgres
```

# How-to Setup things in pycharm

```
Install Python 3.12.3
Create Virtual Env From Base Python 3.12.3
Activate Virtual Environment
pip install -r dev_requirements.txt
configure DB
    default username: abhishek, password: novell, host:localhost, port:5432, db_name:mwo-services
    export DATABASE_URL='postgresql+asyncpg://abhishek:novell@localhost:5432/mwo-services'
                                    OR
    create file .env.dev and paste ---> DATABASE_URL=postgresql+asyncpg://abhishek:novell@localhost:5432/mwo-services
uvicorn main:app --reload
Mwo Services will be available at http://127.0.0.1:8000 
Swagger Doc at http://127.0.0.1:8000/docs
Redoc Doc at  http://127.0.0.1:8000/redoc
```

# How-to Setup db and mwo-services within docker

```
Prerequisites
docker& docker-compose binary should be present 
docker-compose up -d
Mwo Services will be available at http://127.0.0.1:8000 
Swagger Doc at http://127.0.0.1:8000/docs
Redoc Doc at  http://127.0.0.1:8000/redoc
```

# Run All Tests 
```
pytest tests
```

# Generate Test Report And Code Coverage
```
make pytest_code_coverage_test_report
```

# Check Code Quality
```
make lint_all
```
# START/STOP/STATUS ALL SERVICES

```
chmod +x manage_services.sh
Start All services
./manage_services.sh start
Stop All services
./manage_services.sh stop
Restart All services
./manage_services.sh restart
All services Status
./manage_services.sh status
Enable All Services
./manage_services.sh enable
```

# Update the Env values for FastAPI service in dev server

```
Run the below commands (same sequence) in the Dev server 

1.Stop the server
    cd ~/mwo-services/
    ./manage_services.sh stop

2.Edit the environment variables configured as fastapi service
    cd /etc/systemd/system/
    sudo vi fastapi.service
    sudo vi rqdashboard.service
    sudo vi rqscheduler.service
    sudo vi rqsignalworker.service
    sudo vi rqworker.service    
    cd -
    
3.Reset the redis data (use cli and FLUSHALL the data)
    redis-cli  

4.Reload the services to get the latest env 
    sudo systemctl daemon-reload

5.Start the services
    ./manage_services.sh restart
```
